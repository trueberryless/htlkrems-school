# Differences

While in project manual everything is planned ahead and problems that evolve along the way needs to be handled in meetings.

The requirements specifications don't change during the project. The Product Backlog is dynamic and constantly evolving.

# Similarities

In "normal" project management, all things that need to be done are defined in the requirements specification document, while in agile management, the backlog shows all to-dos.

# Contents

-   Requirements specification / Backlog: changes not at all / changes all the time
-   Work breakdown structure or Work Package description / Sprint: is planned ahead / comes as it goes
-   Planing Team / Scrum Team: only at start of project / overlooks developers all the time
-   Project Team / Developer: pretty much the same
