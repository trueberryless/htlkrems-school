# Gray Project Management

This is a mixture of agile project management with SCRUM and Kanban and default project management, with the requirement specifications, communication document, and so on...

At the start of the project you plan ahead what things needs to be done in a Kanban baord. However, you don't need to guess the time for the different to-dos. Then you start the project after a short planning and start the first sprint which is already defined on the Kanban board. Multiple sprints can be completed simultaneously by different teams. This has the advantage that progress is made faster. The teams needs to be splitted smart, for example one team programs Frontend, other team Backend.

Disadvantage: could go on forever
