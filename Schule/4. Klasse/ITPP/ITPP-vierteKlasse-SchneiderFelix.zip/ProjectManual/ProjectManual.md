# Project manual

## Table of Content

Lists all headings in the document to make sure that everybody finds what they want fast.

## Introduction / Overview

Gives an Overview over the document and describes it's purpose.
Describes the basic rules of the company in a short way.

## People and Roles

Lists all possible roles in the company, for example project owner, leader, team mate...
Describes the basic concept of what people in the company are supposed to do.
In a school, for example, there are teachers who teach and students who study.

## Phases

Describes the phases in a project, for example, the pre-project, rough planing, detailed planing, implementation, post-project.

## Documents

Lists and describes all the necessary documents for a project in detail.

## [maybe] Templates

Provide a basic template for every document which is listed in the documents chapter and should be created during a project.
