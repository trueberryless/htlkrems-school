# TrainIT

All documents are saved on the jira website. The backlog, the sprint and all task and issues are saved on their servers.
The programming data (cs Files, Dockerfiles and all the other cool stuff) is saved in a GitHub repository, which logically automatically supports version control, like a good DMS.
