# Identifying Professor Panhofer's leadership

Panhofer leads with the Participative Leadership because he listens to the pupils and lets decide them sometimes what to do first.
Moreover, the communication is very opened and spontaneous. He doesn't blame anyone individually and as a whole class we work together to understand the content of the subjects.
