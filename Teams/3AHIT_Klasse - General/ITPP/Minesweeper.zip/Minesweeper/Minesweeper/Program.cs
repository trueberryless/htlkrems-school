﻿using System;
using libminesweeper;

namespace Minesweeper
{
    class Program
    {
        public const int SIZE = 18;

        static void Main(string[] args)
        {
            libminesweeper.Minesweeper m = new libminesweeper.Minesweeper();
            while (true)
            {
                int bombcount = 35; //provisorisch
                Title(bombcount);

                Menu(m);
            }
        }


        static void Title(int bombcount)
        {
            Console.WriteLine("MINESWEEPER {0}", bombcount);
        }

        static void Menu(libminesweeper.Minesweeper m)
        {
            bool stop = true;
            do
            {
                Console.WriteLine("Wollen Sie ein Feld auswählen (P), neu starten (X) oder das Spiel beenden (E)?");
                // Panel, Xtreme Restart (nonsense), Exit 
                string menu_input = Console.ReadLine();
                menu_input = menu_input.ToUpper();

                switch (menu_input)
                {
                    case "P": Panel(m); break;
                    //case "X": Restart(); break;
                    case "E": stop = false; break;
                    default: Console.WriteLine("Ungültige Eingabe! Versuche es nochmal!"); break;
                }
            } while (stop);
        }
        static void Panel(libminesweeper.Minesweeper m)
        {
            Console.WriteLine("Welches Feld wollen Sie auswählen? (erst Zahl, dann Buchstabe)");
            int posxzahl = Convert.ToInt32(Console.ReadLine());
            char posychar = Convert.ToChar(Console.ReadLine().ToLower());

            Console.WriteLine("Soll das Feld aufgedeckt oder geflagt werden? (R/F) \nOder drücke E um zurückzukehren!");
            //Reveal, Flag, Exit
            string panel_action = Console.ReadLine().ToUpper();

            int posyzahl = -1;
            switch (posychar)
            {
                case 'a': posyzahl = 0; break;
                case 'b': posyzahl = 1; break;
                case 'c': posyzahl = 2; break;
                case 'd': posyzahl = 3; break;
                case 'e': posyzahl = 4; break;
                case 'f': posyzahl = 5; break;
                case 'g': posyzahl = 6; break;
                case 'h': posyzahl = 7; break;
                case 'i': posyzahl = 8; break;
                case 'j': posyzahl = 9; break;
                case 'k': posyzahl = 10; break;
                case 'l': posyzahl = 11; break;
                case 'm': posyzahl = 12; break;
                case 'n': posyzahl = 13; break;
                case 'o': posyzahl = 14; break;
                case 'p': posyzahl = 15; break;
                case 'q': posyzahl = 16; break;
                case 'r': posyzahl = 17; break;
                default: posyzahl = 0; break;
            }

            bool stop = true;
            do
            {
                switch (panel_action)
                {
                    case "R": m.Play(posxzahl, posyzahl, EAction.OPEN); break;
                    case "F": m.Play(posxzahl, posyzahl, EAction.FLAG); break;
                    case "E": stop = false; break;
                    default: Console.WriteLine("Ungültige Eingabe! Versuche es nochmal!"); break;
                }
            } while (stop);
        }

        static void GenerateField(EField[,] Feld)
        {

            Console.SetCursorPosition(0, 0);


            char[] alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R' };

            for (int i = 0; i < SIZE + 1; i++)
            {
                if (i == 0)
                {
                    Console.Write("  ");
                }
                else
                {
                    if (i >= 10)
                    {
                        Console.Write(" " + (i));
                    }
                    else
                    {
                        Console.Write(" " + (i) + " ");
                    }

                }
            }

            Console.WriteLine();
            for (int i = 0; i < SIZE; i++)
            {

                Console.Write(alphabet[i] + " ");
                Console.ForegroundColor = ConsoleColor.Black;
                for (int j = 0; j < SIZE; j++)
                {
                    if(Feld == null)
                    {
                        Console.BackgroundColor = ConsoleColor.Gray; 
                        Console.Write("| |");
                    }                        
                    else
                    switch (Feld[i, j])
                    {
                        case EField.BOMB: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.ZERO: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.ONE: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.TWO: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.THREE: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.FOUR: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.FIVE: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.SIX: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.SEVEN: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.EIGHT: Console.BackgroundColor = ConsoleColor.Gray; Console.Write("| |"); break;
                        case EField.BOMBFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.ZEROFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.ONEFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.TWOFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.THREEFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.FOURFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.FIVEFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.SIXFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.SEVENFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.EIGHTFLAG: Console.BackgroundColor = ConsoleColor.Blue; Console.Write("|F|"); break;
                        case EField.BOMBACTIVATED: Console.BackgroundColor = ConsoleColor.Red; Console.Write("|*|"); break;
                        case EField.ZEROACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|0|"); break;
                        case EField.ONEACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|1|"); break;
                        case EField.TWOACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|2|"); break;
                        case EField.THREEACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|3|"); break;
                        case EField.FOURACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|4|"); break;
                        case EField.FIVEACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|5|"); break;
                        case EField.SIXACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|6|"); break;
                        case EField.SEVENACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|7|"); break;
                        case EField.EIGHTACTIVATED: Console.BackgroundColor = ConsoleColor.White; Console.Write("|8|"); break;
                        default:  break;
                    }

                }
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine();
            }

        }
    }


}
