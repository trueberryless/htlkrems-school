﻿namespace Factory;

public class MachineB
{
    public static SemaphoreSlim slim = new SemaphoreSlim(0);
    public void Run()
    {
        while (true)
        {
            slim.Wait();
            Process();
            Crane.slim.Release();
        }
    }

    public void Process()
    {
        Thread.Sleep(150);
        Console.WriteLine("MachineB finished work");
    }
}