﻿namespace Factory;

public class MachineA
{
    public static SemaphoreSlim slim = new SemaphoreSlim(0);
    public void Run()
    {
        while (true)
        {
            slim.Wait();
            Process();
            Crane.slim.Release();
        }
    }

    public void Process()
    {
        Thread.Sleep(100);
        Console.WriteLine("MachineA finished work");
    }
}