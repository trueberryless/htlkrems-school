﻿namespace Factory;

public class Crane
{
    public static SemaphoreSlim slim = new SemaphoreSlim(0);
    public void Run()
    {
        while (true)
        {
            
            Move("Storage","MachineA");
            MachineA.slim.Release();
            slim.Wait();
            Move("MachineA","MachineB");
            MachineB.slim.Release();
            slim.Wait();
            Move("MachineB","Storage2");
            
        }
    }

    public void Move(string from, string to)
    {
        Thread.Sleep(200);
        Console.WriteLine($"moving from {from} to {to}");
    }
}