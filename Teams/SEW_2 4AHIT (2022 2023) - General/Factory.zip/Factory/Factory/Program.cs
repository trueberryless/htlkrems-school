﻿using Factory;

Crane crane = new Crane();
MachineA machineA = new MachineA();
MachineB machineB = new MachineB();
new Thread(crane.Run).Start();
new Thread(machineA.Run).Start();
new Thread(machineB.Run).Start();