namespace Racing; 

public class F1Race {
    
    public F1Race() {
    }
    
    
    public void Run(){
        Start();
        
        End();
    }
    private void Start(){
        Console.WriteLine("Starting Race");
        Thread.Sleep(1000);
    }
    private void End(){
        Console.WriteLine("Race finished");
    }

}