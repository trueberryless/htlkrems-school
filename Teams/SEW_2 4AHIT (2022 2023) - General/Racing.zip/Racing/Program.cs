﻿ // See https://aka.ms/new-console-template for more information

 using Racing;

string[] drivers = {"Nikki Lauda", "Ayrton Senna", "Fernando Alonso", "Mika Häkkinen", "Michael Schumacher"};
