﻿namespace LinqVorbereitung;

internal class Person
{
    public int Id { get; set; }
    public string Name { get => $"Person {Id}"; }
}
