﻿namespace LinqVorbereitung;

internal class ItemMapping
{
    public Person Owner { get; set; }
    public IList<Item> Items { get; set; }
}
