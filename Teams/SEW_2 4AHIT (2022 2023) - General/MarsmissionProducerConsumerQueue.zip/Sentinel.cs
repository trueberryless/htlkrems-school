using System.Collections.Concurrent;

namespace MarsmissionFixed; 

public class Sentinel {
    private readonly BlockingCollection<ResourcesFoundMessage> _messageQueue;
    private readonly SemaphoreSlim _harvesterAcknowledge = new SemaphoreSlim(0);
    private static int resourceCount = 0;

    public string Code { get; init; }
    

    public Sentinel(string code, BlockingCollection<ResourcesFoundMessage> messageQueue) {
        Code = code;
        _messageQueue = messageQueue;
    }
    
    public void Run() {
        while(true) {
            ScanningSurface();
            var incrementedCount = Interlocked.Increment(ref resourceCount);
            var position = $"{Code}_{incrementedCount}";
            Signal(position);
            _messageQueue.Add(new ResourcesFoundMessage
            {
                Position = position,
                Acknowledge = _harvesterAcknowledge
            });
            _harvesterAcknowledge.Wait();
        }
    }
    private void ScanningSurface(){
        Console.WriteLine($"{Code}: Scanning Surface");
        Thread.Sleep(500);
    }
    private void Signal(string position){
        Thread.Sleep(800);
        Console.WriteLine(
            $"{Code}: Found raw material at position {position}"
        );
    }

}