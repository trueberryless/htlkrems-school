using System.Collections.Concurrent;

namespace MarsmissionFixed; 

public class Harvester
{
    private readonly BlockingCollection<ResourcesFoundMessage> _messageQueue;

    public static readonly SemaphoreSlim StorageGuard = new SemaphoreSlim(2);

    public string Code { get; init; }

    public Harvester(string code, BlockingCollection<ResourcesFoundMessage> messageQueue) {
        Code = code;
        _messageQueue = messageQueue;
    }
    
    public void Run(){
        while(true) {
            var msg = _messageQueue.Take();
            Acknowledge(msg.Position);
            msg.Acknowledge.Release();
            Harvest(msg.Position);
            
            StorageGuard.Wait();
            Store();
            StorageGuard.Release();
        }
    }
    
    private void Acknowledge(string position){
        Console.WriteLine($"{Code}: Acknowledging signal for position {position}");
        Thread.Sleep(100);
    }
    private void Harvest(string position){
        Console.WriteLine($"{Code}: Harvesting resources at position {position}");
        Thread.Sleep(1000);
    }
    private void Store(){
        Console.WriteLine($"{Code}: Storing resources");
        Thread.Sleep(200);
    }
    
}