﻿using System.Collections.Concurrent;

namespace MarsmissionFixed
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var messageQueue = new BlockingCollection<ResourcesFoundMessage>();
            new Thread(new Sentinel("CX-1", messageQueue).Run).Start();
            new Thread(new Sentinel("CX-2", messageQueue).Run).Start();

            new Thread(new Harvester("HKA-1", messageQueue).Run).Start();
            new Thread(new Harvester("HKA-2", messageQueue).Run).Start();
            new Thread(new Harvester("HKA-3", messageQueue).Run).Start();
            new Thread(new Harvester("HKA-4", messageQueue).Run).Start();
        }
    }
}