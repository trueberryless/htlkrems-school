﻿namespace MarsmissionFixed
{
    public class ResourcesFoundMessage
    {
        public string Position { get; set; }
        public SemaphoreSlim Acknowledge { get; set; }
    }
}
