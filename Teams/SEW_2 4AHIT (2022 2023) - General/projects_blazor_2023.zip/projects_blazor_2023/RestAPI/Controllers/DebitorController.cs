using Domain.Repositories.Interfaces;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Model.Entities.Debitors;
using RestAPI.Dtos;

namespace RestAPI.Controllers; 

[ApiController]
[Route("debitors")]
public class DebitorController : AController<Debitor, CreateDebitorDto, ReadDebitorDto, UpdateDebitorDto> {
    
    public DebitorController(IDebitorRepository repository, ILogger<AController<Debitor, CreateDebitorDto, ReadDebitorDto, UpdateDebitorDto>> logger) : base(repository, logger) {
    }


    [HttpGet("graphs")]
    public async Task<ActionResult<List<ReadDebitorGraphDto>>> ReadAllGraphAsync() {
        var repository = (IDebitorRepository)Repository;
        var data = await repository.ReadAllGraphAsync();

        return Ok(data.Select(d => d.Adapt<ReadDebitorGraphDto>()));
    }
}