using Domain.Repositories.Interfaces;
using Mapster;
using Microsoft.AspNetCore.Mvc;

namespace RestAPI.Controllers; 

public abstract class AController<TEntity, TCreateEntityDto, TReadEntityDto, TUpdateEntityDto> : ControllerBase  
    where TEntity : class
    where TCreateEntityDto : class
    where TUpdateEntityDto : class
    where TReadEntityDto : class
{
    protected readonly IRepository<TEntity> Repository;

    protected readonly ILogger<AController<TEntity, TCreateEntityDto, TReadEntityDto, TUpdateEntityDto>> Logger;

    public AController(IRepository<TEntity> repository, ILogger<AController<TEntity, TCreateEntityDto, TReadEntityDto, TUpdateEntityDto>> logger) {
        Repository = repository;
        Logger = logger;
    }

    
    [HttpGet("{id:int}")]
    public async Task<ActionResult<TReadEntityDto>> ReadAsync(int id) {
        TEntity? data = await Repository.ReadAsync(id);

        if (data is null) {
            Logger.LogInformation($"Invalid Request: Entity not present - {id}");
            return NotFound();
        }

        Logger.LogInformation($"Sending Entity: {id}");
        return Ok(data.Adapt<TReadEntityDto>());
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult> UpdateAsync(int id, TUpdateEntityDto record) {
        TEntity? data = await Repository.ReadAsync(id);

        if (data is null) {
            Logger.LogInformation($"Invalid Request: Entity not present - {id}");
            return NotFound();
        }
        
        await Repository.UpdateAsync(record.Adapt<TEntity>());
        Logger.LogInformation($"Updated Entity: {id}"); 
        
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<ActionResult> DeleteAsync(int id) {
        TEntity? data = await Repository.ReadAsync(id);

        if (data is null) {
            return NotFound();
        }
       
        await Repository.DeleteAsync(data);
        Logger.LogInformation($"Deleted Entity: {id}");

        return NoContent();
    }

    [HttpGet]
    public async Task<ActionResult<List<TReadEntityDto>>> ReadAllAsync() {
        var data = await Repository.ReadAllAsync();
        
        var dtos = data.Select(p => p.Adapt<TReadEntityDto>()).ToList();
        return Ok(dtos);
    }

    [HttpPost]
    public async Task<ActionResult<TReadEntityDto>> CreateAsync(TCreateEntityDto pokemon) =>
        Ok((await Repository.CreateAsync(pokemon.Adapt<TEntity>())).Adapt<TReadEntityDto>());
    
}



