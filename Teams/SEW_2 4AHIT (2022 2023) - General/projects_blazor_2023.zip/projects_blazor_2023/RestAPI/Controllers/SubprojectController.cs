using Domain.Repositories.Interfaces;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Model.Entities.Projects;
using RestAPI.Dtos;

namespace RestAPI.Controllers; 


[ApiController]
[Route("subprojects")]
public class SubprojectController : AController<Subproject, CreateSubprojectDto, ReadSubprojectDto, UpdateSubprojectDto> {
    
    public SubprojectController(ISubprojectRepository repository, ILogger<AController<Subproject, CreateSubprojectDto, ReadSubprojectDto, UpdateSubprojectDto>> logger) : base(repository, logger) {
    }

    [HttpGet("graphs")]
    public async Task<ActionResult<List<ReadSubprojectGraphDto>>> ReadGraphAsync() {
        var data = await ((ISubprojectRepository)Repository).ReadAllGraphAsync();
        var result = data.Select(s => s.Adapt<ReadSubprojectGraphDto>());
        
        return Ok(result);
    }
}