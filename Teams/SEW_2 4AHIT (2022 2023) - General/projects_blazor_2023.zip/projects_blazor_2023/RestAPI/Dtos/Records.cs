namespace RestAPI.Dtos;


public record ReadLegalFoundationDto(string Label, string Description);