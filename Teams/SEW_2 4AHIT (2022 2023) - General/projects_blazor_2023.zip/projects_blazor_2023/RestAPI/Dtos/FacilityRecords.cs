namespace RestAPI.Dtos; 

public record ReadFacilityDto(int Id, string Description, string FacilityCode, string FacilityTitle);