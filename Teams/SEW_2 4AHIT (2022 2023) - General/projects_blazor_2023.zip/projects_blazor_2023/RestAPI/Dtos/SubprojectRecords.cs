using System.ComponentModel.DataAnnotations;
using Model.Entities.Facilities;

namespace RestAPI.Dtos; 


public record ReadSubprojectDto(int Id, string Description,  int AppliedResearch,  int TheoreticalResearch, int FocusResearch, int ProjectId, int InstituteId);
public record ReadSubprojectGraphDto(int Id, string Description,  int AppliedResearch,  int TheoreticalResearch, int FocusResearch, int ProjectId, ReadAProjectDto Project, int InstituteId, ReadFacilityDto Institute);
public record CreateSubprojectDto(string Description, [Range(0, 100)] int AppliedResearch, [Range(0, 100)] int TheoreticalResearch, [Range(0, 100)] int FocusResearch, int ProjectId, int InstituteId);
public record UpdateSubprojectDto(int Id, string Description, [Range(0, 100)] int AppliedResearch, [Range(0, 100)] int TheoreticalResearch, [Range(0, 100)] int FocusResearch, int ProjectId, int InstituteId);
