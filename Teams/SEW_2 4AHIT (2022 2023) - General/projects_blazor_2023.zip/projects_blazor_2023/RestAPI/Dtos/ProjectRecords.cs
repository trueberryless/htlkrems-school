using Model.Entities.Projects;

namespace RestAPI.Dtos; 

public record ReadAProjectDto(int Id, string Title, string Description, DateTime CreatedAt);
public record ReadRequestFundingProjectDto(int Id, string Title, string Description, DateTime CreatedAt, bool IsSmallProject) : ReadAProjectDto(Id, Title, Description, CreatedAt);
public record ReadResearchFundingProjectDto(int Id, string Title, string Description, DateTime CreatedAt, bool IsEuSponsored, bool IsFFGSponsored, bool IsFWFSponsored) : ReadAProjectDto(Id, Title, Description, CreatedAt);
public record ReadManagementProjectDto(int Id, string Title, string Description, DateTime CreatedAt,  DateTime ProjectEnd, EManagementDuty ManagementDuty) : ReadAProjectDto(Id, Title, Description, CreatedAt);
