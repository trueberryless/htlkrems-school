using System.ComponentModel.DataAnnotations;

namespace RestAPI.Dtos; 

public record CreateDebitorDto([StringLength(100)] string Description, [StringLength(20)] string Name);
public record UpdateDebitorDto(int Id, [StringLength(100)] string Description, [StringLength(20)] string Name);
public record ReadDebitorDto(int Id, string Description, string Name);
public record ReadDebitorGraphDto(int Id, string Description, string Name, List<ReadProjectDebitorDto> Projects);

public record ReadProjectDebitorDto(float Amount, int ProjectId, ReadAProjectDto Project);