using Domain.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using Model.Configurations;
using Model.Entities.Projects;

namespace Domain.Repositories.Implementations; 

public class SubprojectRepository : ARepository<Subproject>, ISubprojectRepository  {
    public SubprojectRepository(ProjectDbContext context) : base(context) {
    }

    public async Task<List<Subproject>> ReadAllGraphAsync() => await Table
        .Include(s => s.Institute)
        .Include(s => s.Project)
        .ToListAsync();
}