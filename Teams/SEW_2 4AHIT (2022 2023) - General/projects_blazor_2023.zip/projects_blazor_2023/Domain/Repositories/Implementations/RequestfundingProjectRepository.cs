using Model.Configurations;
using Model.Entities.Projects;

namespace Domain.Repositories.Implementations; 

public class RequestfundingProjectRepository  : ARepository<RequestFundingProject> {
    
    public RequestfundingProjectRepository(ProjectDbContext context) : base(context) {
    }
    
}