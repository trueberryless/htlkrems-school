using Domain.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using Model.Configurations;
using Model.Entities.Debitors;

namespace Domain.Repositories.Implementations; 

public class DebitorRepository : ARepository<Debitor>, IDebitorRepository {
    public DebitorRepository(ProjectDbContext context) : base(context) {
    }

    public async Task<List<Debitor>> ReadAllGraphAsync() => 
        await Table
            .Include(d => d.Projects)
            .ThenInclude(pd => pd.Project)
            .ToListAsync();
}