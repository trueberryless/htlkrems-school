using Model.Entities.Debitors;

namespace Domain.Repositories.Interfaces; 

public interface IDebitorRepository : IRepository<Debitor> {

    Task<List<Debitor>> ReadAllGraphAsync();

}