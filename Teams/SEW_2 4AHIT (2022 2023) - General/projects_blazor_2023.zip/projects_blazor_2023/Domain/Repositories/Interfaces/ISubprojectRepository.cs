using Model.Entities.Projects;

namespace Domain.Repositories.Interfaces; 

public interface ISubprojectRepository : IRepository<Subproject> {

    Task<List<Subproject>> ReadAllGraphAsync();

}