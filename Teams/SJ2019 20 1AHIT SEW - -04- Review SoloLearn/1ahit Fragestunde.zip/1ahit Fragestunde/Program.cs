﻿using System;

namespace _1ahit_Fragestunde
{
    class Program
    {
        static void Main(string[] args)
        {
            // var legt den Datentyp SELBST fest
            var name = "Herwig"; // wird zu string
            var alter = 50;      // wird zu int

            // In Wirklichkeit steht da:
            // string name = "Herwig"; // wird zu string
            // int alter = 50;         // wird zu int

            // damit ist klar, dass folgendes ned geht
            // name = alter;

            //Operator

            bool erwachsen;
            if (alter >= 18)
                erwachsen = true;
            else
                erwachsen = false;

            if (alter >= 18) erwachsen = true;else erwachsen = false;

            erwachsen = alter >= 18 ? true : false;

            Console.WriteLine(bsp1(4));   //8
            Console.WriteLine(bsp1(4, 3)); //7
            Console.WriteLine(bsp1(4, "ABC")); //4ABC

            int x = 2, y, z=3;
            RefOutBsp(ref x, out y, z);//x=8, y=9, z=3

            //praxis
            //Int32.TryParse(Console.ReadLine(), out y);

            //Mehrdimensinale Arrays

            int[,] ttt = new int[3, 3]; //2d array
            ttt[0, 0] = 1; //links oben steht 1 für spieler 1
            ttt[0, 1] = 2; // spieler 2
            ttt[0, 2] = 1; // spieler 1
            ttt[2, 1] = 2; // spieler 2

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(ttt[i,j] + " ");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }

        static int bsp1(int x)
        {
            return x + x;
        }
        static int bsp1(int x, int y)
        {
            return x + y;
        }
        static string bsp1(int x, string y)
        {
            return "" + x + y;
        }

        static void RefOutBsp(ref int a, out int b, int c)
        {
            a = 8;
            b = 9;
            c = 42;
        }
    }
}
