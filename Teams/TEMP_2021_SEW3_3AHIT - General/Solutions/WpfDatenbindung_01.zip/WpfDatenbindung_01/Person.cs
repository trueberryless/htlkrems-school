﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Input;
using System.Linq;
using System.IO;

namespace WpfDatenbindung_01
{
    // Model
    public class Person {
        public int Age { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return Name+";"+Age;
        }
    }

    // This class implements INotifyPropertyChanged
    // to support one-way and two-way bindings
    // (such that the UI element updates when the source
    // has been changed dynamically)
    public class PersonVM : INotifyPropertyChanged
    {
        public ICommand AddCommand { get; private set; }
        public ICommand DelCommand { get; private set; }
        public ICommand ChgCommand { get; private set; }
        public ICommand SaveCommand { get; private set; }
        public ICommand LoadCommand { get; private set; }

        public ObservableCollection<PersonVM> _allpersons;
        public ObservableCollection<PersonVM> AllPersons
        {
            get { if (_allpersons == null)
                {
                    _allpersons = new ObservableCollection<PersonVM>();
                    _allpersons.Add(new PersonVM(new Person { Name = "Susi" , Age=4 }));
                    _allpersons.Add(new PersonVM(new Person { Name = "Karli", Age=5 }));
                }
                return _allpersons;
            }
            set { _allpersons = value;
                OnPropertyChanged();
            }
        }
        private PersonVM _selectedPerson;
        public PersonVM SelectedPerson
        {
            get { return _selectedPerson; }
            set { 
                _selectedPerson = value;
            }
        }


        private Person person;
        // Declare the event
        public event PropertyChangedEventHandler PropertyChanged;

        public PersonVM()
        {
            this.person = new Person();
            AddCommand = new AddUserCmd(this);
            DelCommand = new DelUserCmd(this);
            ChgCommand = new ChgUserCmd(this);
            SaveCommand = new SaveCmd(this);
            LoadCommand = new LoadCmd(this);
        }

        public PersonVM(Person value)
        {
            this.person = value;
        }

        public string PersonName
        {
            get { return person?.Name; }
            set
            {
                person.Name = value;
                // Call OnPropertyChanged whenever the property is updated
                OnPropertyChanged();
            }
        }
        public int PersonAge
        {
            get { return person.Age; }
            set
            {
                person.Age = value;
                // Call OnPropertyChanged whenever the property is updated
                OnPropertyChanged();
            }
        }

        // Create the OnPropertyChanged method to raise the event
        // The calling member's name will be used as the parameter.
        protected virtual void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public override string ToString()
        {
            return person.ToString();
        }
    }

    public class ChgUserCmd : ICommand
    {
        PersonVM parent;
        public ChgUserCmd() { }
        public ChgUserCmd(PersonVM parent)
        {
            this.parent = parent;
        }
        public bool CanExecute(object parameter)
        {
            return parent.SelectedPerson != null;
        }

        public void Execute(object parameter)
        {
            parent.SelectedPerson = null;
            parent.PersonName = null;
        }
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
    public class DelUserCmd : ICommand {
        PersonVM parent;
        public DelUserCmd(){}
        public DelUserCmd(PersonVM parent) { 
            this.parent = parent;
        }
        public bool CanExecute(object parameter)
        {
            return parent.SelectedPerson!= null;

        }

        public void Execute(object parameter)
        {
            parent.AllPersons.Remove(parent.SelectedPerson);
            parent.SelectedPerson = null;
        }
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }   
    public class AddUserCmd : ICommand
    {
        PersonVM parent;
        public AddUserCmd() { }
        public AddUserCmd(PersonVM parent)
        {
            this.parent = parent;
        }

        public bool CanExecute(object parameter)
        {
            return !string.IsNullOrEmpty(parent.PersonName);
        }

        public void Execute(object parameter)
        {
            Person p = new Person { Name = parent.PersonName, Age=parent.PersonAge };
            parent.AllPersons.Add(new PersonVM(p));
            parent.PersonName = null;
            parent.PersonAge = 0;
        }
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
    public class SaveCmd : ICommand
    {
        PersonVM parent;
        public SaveCmd() { }
        public SaveCmd(PersonVM parent)
        {
            this.parent = parent;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            using (StreamWriter sw = new StreamWriter("data.csv"))
            foreach (var item in parent.AllPersons)
            {
                    sw.WriteLine(item);
            }
        }
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
    public class LoadCmd : ICommand
    {
        PersonVM parent;
        public LoadCmd() { }
        public LoadCmd(PersonVM parent)
        {
            this.parent = parent;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            parent.AllPersons = new ObservableCollection<PersonVM>();
            using (StreamReader sr = new StreamReader("data.csv"))
                while (sr.Peek() > 0)
                {
                    var line = sr.ReadLine().Split(";");
                    parent.AllPersons.Add(new PersonVM(new Person { 
                        Name = line[0], Age=Convert.ToInt32(line[1]) 
                    }));
                }
                    

        }
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}
