﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;

namespace WpfDatabinding02
{
    public enum Mark { SehrGut, Gut, Befriedigend, Genuegend, NichtGenuegend};
    // Model
    public class Person
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public bool Male { get; set; }
        public int Points { get; set; }

        //public string Mark{ get; set; }

        public override string ToString()
        {
            return Name + ";" + Age;
        }
    }

    // ViewModel
    public class PersonVM : INotifyPropertyChanged
    {
        public ICommand AddCmd { get; set; }

        private ObservableCollection<PersonVM> _allpersons;
        public ObservableCollection<PersonVM> AllPersons
        {
            get
            {
                if (_allpersons == null)
                {
                    _allpersons = new ObservableCollection<PersonVM>();
                    // in realerer Situation CSV laden?? 
                    _allpersons.Add(new PersonVM(new Person { Name = "Susi", Age = 4 }));
                    _allpersons.Add(new PersonVM(new Person { Name = "Karli", Age = 5, Male=true }));
                }
                return _allpersons;
            }
            set
            {
                _allpersons = value;
                OnPropertyChanged();
            }
        }
        private PersonVM _selectedPerson;
        public PersonVM SelectedPerson
        {
            get { return _selectedPerson; }
            set
            {
                _selectedPerson = value;
            }
        }

        private Person person;
        public PersonVM()
        {
            this.person = new Person();
            AddCmd = new AddUserCmd(this);
        }

        public PersonVM(Person p) { this.person = p; }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propname=null)
        {
            if (PropertyChanged != null)
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propname));
        }

        public string PersonName
        {
            get { return person.Name; }
            set {
                if (person.Name != value) {
                    person.Name = value;
                    OnPropertyChanged();
                }
            }
        }
        public int PersonAge
        {
            get { return person.Age; }
            set
            {
                if (person.Age != value)
                {
                    person.Age = value;
                    OnPropertyChanged();
                }
            }
        }
        public int PersonPoints
        {
            get { return person.Points; }
            set
            {
                if (person.Points != value)
                {
                    person.Points = value;
                    OnPropertyChanged();
                }
            }
        }
        //public string PersonMark
        //{
        //    get { return person.Mark; }
        //    set
        //    {
        //        if (person.Mark != value)
        //        {
        //            person.Mark = value;
        //            OnPropertyChanged();
        //        }
        //    }
        //}
        public bool PersonIsMale
        {
            get { return person.Male; }
            set
            {
                if (person.Male != value)
                {
                    person.Male = value;
                    OnPropertyChanged();
                }
            }
        }

        public override string ToString()
        {
            return person.ToString();
        }
    }

    public class AddUserCmd : ICommand
    {
        PersonVM parent;
        public AddUserCmd() { }
        public AddUserCmd(PersonVM parent)
        {
            this.parent = parent;
        }

        public bool CanExecute(object parameter)
        {
            return !string.IsNullOrEmpty(parent.PersonName);
        }

        public void Execute(object parameter)
        {
            Person p = new Person { Name = parent.PersonName, Age = parent.PersonAge };
            parent.AllPersons.Add(new PersonVM(p));
            parent.PersonName = null;
            parent.PersonAge = 0;
        }
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
    public class TrueFalseToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            switch (value.ToString().ToLower()) {
                case "true": return true;
                default: return false;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool) {
                if ((bool)value == true) return "true";
            }
            return "false";

        }
    }
    public class MarkConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int p = Int32.Parse(value.ToString());
            //int p = System.Convert.ToInt32(value.ToString());
            if (p < 51) return "Nicht genügend";
            if (p < 62) return "Genügend";
            if (p < 75) return "Befriedigend";
            if (p < 87) return "Gut";
            else return "Sehr gut";
           
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            
            return 0;

        }
    }
}

