﻿using SEW3_017_LINQ_Abfragen;

Initializer i = new Initializer();
List<GroceryStore> grocery = Initializer.grocery;
List<FurnitureStore> furniture = Initializer.furniture;
List<ClothingStore> clothing = Initializer.clothings;
List<Stores> stores = Initializer.stores;

// Where / Select
// Query Syntax
Console.WriteLine("Welche Produkte sind Bio & kosten weniger als 10€?");
var query1 = from s in grocery where s.Price < 10 && s.IsBIO == true select s;
foreach(var item in query1)
{
    Console.WriteLine(item.Name);
}

// Method Syntax
Console.WriteLine("\nWelche Produkte sind aus den USA?");
var query2 = grocery.Where(s => s.Region == "USA");
foreach (var item in query2)
{
    Console.WriteLine(item.Name);
}


// OfType / Select
Console.WriteLine("\nAlle Objekte von ClothingStore ausgeben");
var query4 = from s in stores.OfType<ClothingStore>() select s;
foreach (var item in query4)
{
    Console.WriteLine(item.ToString());
}

Console.WriteLine("\nAlle Objekte von FurnitureStore ausgeben");
var query5 = from s in stores.OfType<FurnitureStore>() select s;
foreach (var item in query5)
{
    Console.WriteLine(item.ToString());
}

Console.WriteLine("\nAlle Objekte von GroceryStore ausgeben");
var query6 = from s in stores.OfType<GroceryStore>() select s;
foreach (var item in query6)
{
    Console.WriteLine(item.ToString());
}
// Oderby - Thenby
Console.WriteLine("\nAlle Objekte von GroceryStore nach dem Namen aufsteigend sortieren.");
var query20 = from s in grocery orderby s.Name ascending select s;
foreach (var item in query20)
{
    Console.WriteLine(item.Name);
}

Console.WriteLine("\nAlle Objekte von FurnitureStore nach der Produkt ID absteigend sortieren.");
var query21 = from s in furniture orderby s.ProductID descending select s;
foreach (var item in query21)
{
    Console.WriteLine(item.ProductID);
}

Console.WriteLine("\nAlle Objekte von ClothingStore nach dem Namen und dann nach der Kategorie sortieren.");
var query22 = clothing.OrderBy(s => s.Name).ThenBy(s => s.Categories);
foreach (var item in query22)
{
    Console.WriteLine(item.Name + ", " + item.Categories);
}

Console.WriteLine("\nAlle Objekte von GroceryStore nach Namen aufsteigend und dann nach dem Ablaufdatum absteigend sortieren.");
var query23 = grocery.OrderBy(s => s.Name).ThenByDescending(s => s.BestBeforeDate);
foreach (var item in query23)
{
    Console.WriteLine(item.Name + ", " + item.BestBeforeDate);
}

// Groupby
Console.WriteLine("\nGroupBy bei GroceryStore nach der Produkt ID.");
var query24 = from s in grocery group s by s.ProductID;
foreach (var item in query24)
{
    Console.WriteLine("Product ID: " + item.Key);
}

Console.WriteLine("\nGroupBy bei GroceryStore nach dem Ablaufdatum + Name ausgeben.");
var query25 = grocery.GroupBy(s => s.BestBeforeDate);
foreach (var item in query25)
{
    Console.Write($"BestBeforeDate: {item.Key}, Name: ");
    foreach(var item2 in item)
    {
        Console.WriteLine(item2.Name);
    }
}

// ToLookup
Console.WriteLine("\nTooLookup bei FurnitureStore nach der Produkt ID.");
var query26 = furniture.ToLookup(s => s.ProductID);
foreach (var item in query26)
{
    Console.WriteLine("ProductID: " + item.Key);
}

Console.WriteLine("\nTooLookup bei FurnitureStore nach dem Name + Produkt ID ausgeben.");
var query27 = furniture.ToLookup(s => s.Name);
foreach (var item in query27)
{
    Console.Write($"Name: {item.Key}, Produkt ID: ");
    foreach (var item2 in item)
    {
        Console.WriteLine(item2.ProductID);
    }
}

// Where - Average / Sum
Console.WriteLine("\nDurchschnittspreis der Möbel, die aus Glas sind?");
double query7 = furniture.Where(s => s.Material == EMaterial.GLASS).Average(s => s.Price);
Console.WriteLine(query7);

// Where - Count
Console.WriteLine("\nAnzahl von Accessoires?");
double query8 = clothing.Where(s => s.Categories == ECategories.ACCESSOIRES).Count();
Console.WriteLine(query8);

// Where - Max / Min
Console.WriteLine("\nMaximaler Preis von orangen Kleidungsstücken?");
double query9 = clothing.Where(s => s.Color == EColor.ORANGE).Max(s => s.Price);
Console.WriteLine(query9);

Console.WriteLine("\nMinimalste Größe eines Kleidungsstückes, was lieferbar ist?");
double query10 = clothing.Where(s => s.IsDeliverable == true).Min(s => s.Size);
Console.WriteLine(query10);

// Sum
Console.WriteLine("\nSumme aller Preise von Accessoires die lieferbar sind?");
var query11 = clothing.Where(s => s.IsDeliverable == true).Sum(s => s.Price);
Console.WriteLine(query11);

// First(OrDefault)
Console.WriteLine("\nProduct ID des 1. \"Möbelstück\" das eine Küche ist?");
var query12 = furniture.Where(s => s.Type == ETypes.KITCHEN).Select(s => new { s.ProductID }).First();
Console.WriteLine(query12);

// Last(OrDefault)
Console.WriteLine("\nProduct ID des letzten \"Möbelstück\" welches aus Metall besteht?");
var query13 = furniture.Where(s => s.Material == EMaterial.METAL).Select(s => new { s.ProductID }).Last();
Console.WriteLine(query13);

// Single(OrDefault)
Console.WriteLine("\nNamen und Preis des einzigen Möbelstücks, das die Produkt ID 5 hat ausgeben");
var query14 = furniture.Where(s => s.ProductID == 5).Select(s => new { s.Name, s.Price }).Single();
Console.WriteLine(query14);

// Concat -> alle Preise, auch wenn doppelt
Console.WriteLine("\nAlle Preise von Möbelstücken & Kleidungsstücke ausgeben (20x)");
IEnumerable<double> query19 = furniture.Select(s => s.Price).Concat(clothing.Select(t => t.Price));
foreach (var item in query19)
{
    Console.WriteLine(item);
}

// Distinct -> alle Regionen
Console.WriteLine("\nVon welchen Regionen (alle!) stammen die Lebensmittel?");
IEnumerable<string> query15 = grocery.Select(s => s.Region).Distinct();
foreach(var item in query15)
{
    Console.WriteLine(item);
}

// Intersect -> alle Preise, die bei beiden gleich sind
Console.WriteLine("\nWelcher Preis ist bei Möbelstücken & Kleidungsstücken gleich?");
IEnumerable<double> query16 = furniture.Select(s => s.Price).Intersect(clothing.Select(t => t.Price));
foreach (var item in query16)
{
    Console.WriteLine(item);
}

// Except -> alle Preise, die NUR in der 1. Schnittmenge sind
Console.WriteLine("\nPreise, die nur bei Möbelstücken, aber nicht bei Kleidungsstücken vorkommen?");
IEnumerable<double> query17 = furniture.Select(s => s.Price).Except(clothing.Select(t => t.Price));
foreach (var item in query17)
{
    Console.WriteLine(item);
}

// Union -> alle Preise, aber keine doppelt
Console.WriteLine("\nAlle Preise, die bei Möbelstücken & Kleidungsstücken vorkommen -> keine doppelte Ausgabe");
IEnumerable<double> query18 = furniture.Select(s => s.Price).Union(clothing.Select(t => t.Price));
foreach (var item in query18)
{
    Console.WriteLine(item);
}
