﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEW3_017_LINQ_Abfragen
{
    public enum ETypes { SOFA, TABLE, CHAIR, BATHTUB, MIRROR, CARPET, DECO, TOILET, KITCHEN, BED}
    public enum EMaterial { WOOD, GLASS, METAL, PLASTIC, CERAMIC }
    public class FurnitureStore : Stores
    {
        public EMaterial Material { get; set; }
        public ETypes Type { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
        public int Depth { get; set; }


        public FurnitureStore() { }
        public FurnitureStore(EMaterial Material, ETypes Type, int Height, int Width, int Depth, double Price, int ProductID, string Name, bool IsDeliverable) : base(Price, ProductID, Name, IsDeliverable)
        {
            this.Material = Material;
            this.Type = Type;
            this.Height = Height;
            this.Width = Width;
            this.Depth = Depth;
            this.Price = Price;
            this.Name = Name;
            this.ProductID = ProductID;
            this.IsDeliverable = IsDeliverable;
        }
        public override string ToString()
        {
            return Name + " " + ProductID + " " + Height + " " + Width + " " + Depth + " " + Price + " " + IsDeliverable;
        }
    }
}