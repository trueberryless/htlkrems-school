﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEW3_017_LINQ_Abfragen
{
    public enum EStorage { FREZZER, FRIDGE, SHELF, BAKINGBOX, BASKET }
    public class GroceryStore : Stores
    {
        public EStorage Storage { get; set; }
        public string Region { get; set; }
        public bool IsBIO { get; set; }
        public string BestBeforeDate { get; set; }

        public GroceryStore() { }
        public GroceryStore(EStorage storage, string Region, bool IsBIO, string BestBeforeDate, double Price, int ProductID, string Name, bool IsDeliverable) :base ( Price,  ProductID, Name, IsDeliverable)
        {
            this.Storage = storage;
            this.BestBeforeDate = BestBeforeDate;
            this.IsBIO = IsBIO;
            this.Region = Region;
            this.Price = Price;
            this.Name = Name;
            this.ProductID = ProductID;
            this.IsDeliverable = IsDeliverable;
        }
        public override string ToString()
        {
            return Storage + " " + BestBeforeDate + " " + IsBIO + " " + Region + " " + Price + " " + Name + " " + ProductID + " " + IsDeliverable;
        }
    }
}