﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEW3_017_LINQ_Abfragen
{
    public class Initializer
    {
        public static List<ClothingStore> clothings = new List<ClothingStore>()
        {
            new ClothingStore(){ Categories = ECategories.ACCESSOIRES, Color = EColor.ORANGE, Size = 32, ProductID = 1, Name = "or.Earrings", IsDeliverable= true, Price= 40.99},
            new ClothingStore(){ Categories = ECategories.BABYWEAR, Color = EColor.PINK, Size = 62, ProductID = 2, Name = "pi.Baby", IsDeliverable= false, Price= 50.99},
            new ClothingStore(){ Categories = ECategories.BEACHWEAR, Color = EColor.BLUE, Size = 34, ProductID = 3, Name = "bl.Beachwear", IsDeliverable= true, Price= 25.66},
            new ClothingStore(){ Categories = ECategories.ELEGANTCLOTHES, Color = EColor.GREEN, Size = 36, ProductID = 4, Name = "gr.ElegantClothes", IsDeliverable= true, Price= 46.34},
            new ClothingStore(){ Categories = ECategories.ACCESSOIRES, Color = EColor.WHITE, Size = 32, ProductID = 5, Name = "or.Earrings", IsDeliverable= true, Price= 73.32},
            new ClothingStore(){ Categories = ECategories.UNDERWEAR, Color = EColor.YELLOW, Size = 38, ProductID = 6, Name = "se.Slips", IsDeliverable= false, Price= 36.34},
            new ClothingStore(){ Categories = ECategories.SHOES, Color = EColor.BLUE, Size = 40, ProductID = 7, Name = "bl.Shoes", IsDeliverable= false, Price= 16.34},
            new ClothingStore(){ Categories = ECategories.BABYWEAR, Color = EColor.ORANGE, Size = 62, ProductID = 8, Name = "or.Shirt", IsDeliverable= true, Price= 34.56},
            new ClothingStore(){ Categories = ECategories.TROUSERS, Color = EColor.PINK, Size = 36, ProductID = 9, Name = "pi.Shorts", IsDeliverable= false, Price= 27.24},
            new ClothingStore(){ Categories = ECategories.SHOES, Color = EColor.VIOLET, Size = 38, ProductID = 10, Name = "vi.Shoes", IsDeliverable= true, Price= 72.23},
        };

        public static List<GroceryStore> grocery = new List<GroceryStore>()
        {
            new GroceryStore(){ Storage = EStorage.BAKINGBOX, Region = "Austria", IsBIO = true, BestBeforeDate = "1.5.2023", Price = 5.35, ProductID = 1, Name = "Bread", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.BASKET, Region = "USA", IsBIO = false, BestBeforeDate = "6.4.2024", Price = 1.45, ProductID = 2, Name = "Baguette", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.FREZZER, Region = "China", IsBIO = false, BestBeforeDate = "7.4.2023", Price = 8.35, ProductID = 3, Name = "Fruits", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.FRIDGE, Region = "Germany", IsBIO = true, BestBeforeDate = "5.6.2022", Price = 2.78, ProductID = 4, Name = "Milk", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.SHELF, Region = "Greek", IsBIO = true, BestBeforeDate = "6.4.2023", Price = 16.33, ProductID = 5, Name = "Cheese", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.BAKINGBOX, Region = "USA", IsBIO = false, BestBeforeDate = "2.8.2022", Price = 32.64, ProductID = 6, Name = "Meat", IsDeliverable = false},
            new GroceryStore(){ Storage = EStorage.BAKINGBOX, Region = "Austria", IsBIO = true, BestBeforeDate = "6.2.2023", Price = 1.63, ProductID = 7, Name = "Chips", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.BASKET, Region = "Germany", IsBIO = true, BestBeforeDate = "8.4.2022", Price = 6.12, ProductID = 8, Name = "Oats", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.FRIDGE, Region = "USA", IsBIO = false, BestBeforeDate = "3.5.2022", Price = 7.34, ProductID = 9, Name = "Fish", IsDeliverable = false},
            new GroceryStore(){ Storage = EStorage.FREZZER, Region = "China", IsBIO = false, BestBeforeDate = "1.9.2023", Price = 0.43, ProductID = 10, Name = "Beans", IsDeliverable = true}
           };

        public static List<FurnitureStore> furniture = new List<FurnitureStore>()
        {
            new FurnitureStore(){ Material = EMaterial.CERAMIC, Type = ETypes.BATHTUB, Height = 100, Width = 30, Depth = 40, Price = 200, ProductID = 1, Name = "Bathtub01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.GLASS, Type = ETypes.BED, Height = 10, Width = 73, Depth = 80, Price = 300, ProductID = 2, Name = "Bed01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.METAL, Type = ETypes.CARPET, Height = 60, Width = 44, Depth = 45, Price = 346.64, ProductID = 3, Name = "Carpet01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.PLASTIC, Type = ETypes.CHAIR, Height = 80, Width = 88, Depth = 72, Price = 25.66, ProductID = 4, Name = "Chair01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.WOOD, Type = ETypes.DECO, Height = 20, Width = 70, Depth = 16, Price = 263.32, ProductID = 5, Name = "Stairs01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.PLASTIC, Type = ETypes.KITCHEN, Height = 90, Width = 90, Depth = 27, Price = 346.33, ProductID = 6, Name = "Kitchen01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.GLASS, Type = ETypes.MIRROR, Height = 70, Width = 30, Depth = 37, Price = 622.45, ProductID = 7, Name = "Mirror01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.METAL, Type = ETypes.KITCHEN, Height = 9, Width = 40, Depth = 28, Price = 547.34, ProductID = 8, Name = "Kitchen02", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.GLASS, Type = ETypes.TOILET, Height = 40, Width = 30, Depth = 51, Price = 34.56, ProductID = 9, Name = "Toilet01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.CERAMIC, Type = ETypes.TABLE, Height = 300, Width = 50, Depth = 28, Price = 456.45, ProductID = 10, Name = "Table01", IsDeliverable = true }
        };
        public static List<Stores> stores = new List<Stores>() {
        new ClothingStore(){ Categories = ECategories.ACCESSOIRES, Color = EColor.ORANGE, Size = 32, ProductID = 1, Name = "or.Earrings", IsDeliverable= true, Price= 40.99},
            new ClothingStore(){ Categories = ECategories.BABYWEAR, Color = EColor.PINK, Size = 62, ProductID = 2, Name = "pi.Baby", IsDeliverable= false, Price= 50.99},
            new ClothingStore(){ Categories = ECategories.BEACHWEAR, Color = EColor.BLUE, Size = 34, ProductID = 3, Name = "bl.Beachwear", IsDeliverable= true, Price= 25.66},
            new ClothingStore(){ Categories = ECategories.ELEGANTCLOTHES, Color = EColor.GREEN, Size = 36, ProductID = 4, Name = "gr.ElegantClothes", IsDeliverable= true, Price= 46.34},
            new ClothingStore(){ Categories = ECategories.ACCESSOIRES, Color = EColor.WHITE, Size = 32, ProductID = 5, Name = "or.Earrings", IsDeliverable= true, Price= 73.32},
            new ClothingStore(){ Categories = ECategories.UNDERWEAR, Color = EColor.YELLOW, Size = 38, ProductID = 6, Name = "se.Slips", IsDeliverable= false, Price= 36.34},
            new ClothingStore(){ Categories = ECategories.SHOES, Color = EColor.BLUE, Size = 40, ProductID = 7, Name = "bl.Shoes", IsDeliverable= false, Price= 16.34},
            new ClothingStore(){ Categories = ECategories.BABYWEAR, Color = EColor.ORANGE, Size = 62, ProductID = 8, Name = "or.Shirt", IsDeliverable= true, Price= 34.56},
            new ClothingStore(){ Categories = ECategories.TROUSERS, Color = EColor.PINK, Size = 36, ProductID = 9, Name = "pi.Shorts", IsDeliverable= false, Price= 27.24},
            new ClothingStore(){ Categories = ECategories.SHOES, Color = EColor.VIOLET, Size = 38, ProductID = 10, Name = "vi.Shoes", IsDeliverable= true, Price= 72.23},
            new GroceryStore(){ Storage = EStorage.BAKINGBOX, Region = "Austria", IsBIO = true, BestBeforeDate = "1.5.2023", Price = 5.35, ProductID = 1, Name = "Bread", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.BASKET, Region = "USA", IsBIO = false, BestBeforeDate = "6.4.2024", Price = 1.45, ProductID = 2, Name = "Baguette", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.FREZZER, Region = "China", IsBIO = false, BestBeforeDate = "7.4.2023", Price = 8.35, ProductID = 3, Name = "Fruits", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.FRIDGE, Region = "Germany", IsBIO = true, BestBeforeDate = "5.6.2022", Price = 2.78, ProductID = 4, Name = "Milk", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.SHELF, Region = "Greek", IsBIO = true, BestBeforeDate = "6.4.2023", Price = 16.33, ProductID = 5, Name = "Cheese", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.BAKINGBOX, Region = "USA", IsBIO = false, BestBeforeDate = "2.8.2022", Price = 32.64, ProductID = 6, Name = "Meat", IsDeliverable = false},
            new GroceryStore(){ Storage = EStorage.BAKINGBOX, Region = "Austria", IsBIO = true, BestBeforeDate = "6.2.2023", Price = 1.63, ProductID = 7, Name = "Chips", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.BASKET, Region = "Germany", IsBIO = true, BestBeforeDate = "8.4.2022", Price = 6.12, ProductID = 8, Name = "Oats", IsDeliverable = true},
            new GroceryStore(){ Storage = EStorage.FRIDGE, Region = "USA", IsBIO = false, BestBeforeDate = "3.5.2022", Price = 7.34, ProductID = 9, Name = "Fish", IsDeliverable = false},
            new GroceryStore(){ Storage = EStorage.FREZZER, Region = "China", IsBIO = false, BestBeforeDate = "1.9.2023", Price = 0.43, ProductID = 10, Name = "Beans", IsDeliverable = true},
            new FurnitureStore(){ Material = EMaterial.CERAMIC, Type = ETypes.BATHTUB, Height = 100, Width = 30, Depth = 40, Price = 200, ProductID = 1, Name = "Bathtub01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.GLASS, Type = ETypes.BED, Height = 10, Width = 73, Depth = 80, Price = 300, ProductID = 2, Name = "Bed01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.METAL, Type = ETypes.CARPET, Height = 60, Width = 44, Depth = 45, Price = 346.64, ProductID = 3, Name = "Carpet01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.PLASTIC, Type = ETypes.CHAIR, Height = 80, Width = 88, Depth = 72, Price = 25.66, ProductID = 4, Name = "Chair01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.WOOD, Type = ETypes.DECO, Height = 20, Width = 70, Depth = 16, Price = 263.32, ProductID = 5, Name = "Stairs01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.PLASTIC, Type = ETypes.KITCHEN, Height = 90, Width = 90, Depth = 27, Price = 346.33, ProductID = 6, Name = "Kitchen01", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.GLASS, Type = ETypes.MIRROR, Height = 70, Width = 30, Depth = 37, Price = 622.45, ProductID = 7, Name = "Mirror01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.METAL, Type = ETypes.KITCHEN, Height = 9, Width = 40, Depth = 28, Price = 547.34, ProductID = 8, Name = "Kitchen02", IsDeliverable = false },
            new FurnitureStore(){ Material = EMaterial.GLASS, Type = ETypes.TOILET, Height = 40, Width = 30, Depth = 51, Price = 34.56, ProductID = 9, Name = "Toilet01", IsDeliverable = true },
            new FurnitureStore(){ Material = EMaterial.CERAMIC, Type = ETypes.TABLE, Height = 300, Width = 50, Depth = 28, Price = 456.45, ProductID = 10, Name = "Table01", IsDeliverable = true }
    };
    }
}