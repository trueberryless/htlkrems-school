﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEW3_017_LINQ_Abfragen
{
    public enum ECategories { ACCESSOIRES, TOPS, TROUSERS, BEACHWEAR, SHOES, UNDERWEAR, BABYWEAR, ELEGANTCLOTHES };
    public enum EColor { BLACK, BLUE, RED, GREEN, WHITE, VIOLET, YELLOW, ORANGE, PINK };
    public class ClothingStore : Stores
    {
        public ECategories Categories { get; set; }
        public EColor Color { get; set; }
        public int Size { get; set; }

        public ClothingStore() { }
        public ClothingStore(ECategories Categories, EColor Color, int Size, double Price, int ProductID, string Name, bool IsDeliverable) : base(Price, ProductID, Name, IsDeliverable)
        {
            this.Categories = Categories;
            this.Color = Color;
            this.Size = Size;
            this.Price = Price;
            this.Name = Name;
            this.ProductID = ProductID;
            this.IsDeliverable = IsDeliverable;
        }
        public override string ToString()
        {
            return Name + " "+ ProductID + " " + Size + " " + Price + " " + IsDeliverable;
        }
    }
}