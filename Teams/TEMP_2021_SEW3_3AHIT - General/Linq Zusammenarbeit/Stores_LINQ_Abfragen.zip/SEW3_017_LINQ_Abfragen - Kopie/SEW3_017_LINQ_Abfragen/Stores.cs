﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEW3_017_LINQ_Abfragen
{
    public class Stores
    {
        public  double Price { get; set; }
        public  int ProductID { get; set; }
        public  string Name { get; set; }
        public  bool IsDeliverable { get; set; }

        public Stores()
        {
        }
        public Stores(double Price, int ProductID, string Name, bool IsDeliverable)
        {
            this.Price = Price;
            this.ProductID = ProductID;
            this.Name = Name;
            this.IsDeliverable = IsDeliverable;
        }

    }
}