﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEW3_017_LINQ_Abfragen
{
    public class Initializer
    {
        List<ClothingStore> clothings = new List<ClothingStore>()
        {
            new ClothingStore(){ Categories = ECategories.ACCESSOIRES, Color = EColor.ORANGE, Size = 40, ProductID = 1, Name = "or.Earrings", IsDelieverable= true, Price= 40.99},
            new ClothingStore(){ Categories = ECategories.BABYWEAR, Color = EColor.PINK, Size = 5, ProductID = 2, Name = "pi.Baby", IsDelieverable= false, Price= 50.99},
            new ClothingStore(){ Categories = ECategories.BEACHWEAR, Color = EColor.BLUE, Size = 30, ProductID = 3, Name = "or.Earrings", IsDelieverable= true, Price= 70.99},
            new ClothingStore(){ Categories = ECategories.ACCESSOIRES, Color = EColor.ORANGE, Size = 40, ProductID = 4, Name = "or.Earrings", IsDelieverable= true, Price= 40.99}
        };
       
    }
}