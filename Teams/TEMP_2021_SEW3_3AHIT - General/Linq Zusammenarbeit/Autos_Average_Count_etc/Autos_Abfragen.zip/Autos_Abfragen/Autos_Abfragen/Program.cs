﻿// See https://aka.ms/new-console-template for more information
using Autos_Abfragen;

InitializerClass i = new InitializerClass();

static void LinqAverage1(InitializerClass i)
{
    //Durchschnittspreis von den Autos von VW welche keine Kilometer haben. 
    var result = i.vw.Where(s => s.Kilometers == 0).Average(s => s.Price);
    Console.WriteLine("Durchschnittspreis von den Autos mit keinen Kilometer: {0}", result);

}
static void LinqAverage2(InitializerClass i)
{
    //Durchschnittskilometer von den Autos von Audi die über 100.000€ kosten. 
    var result = i.a.Where(s => s.Price >= 100000).Average(s => s.Kilometers);
    Console.WriteLine("Durchschnittskilometer: {0}", result);

}
static void LinqCount1(InitializerClass i)
{
    //Anzahl von den Autos von Audi welche keine Kilometer haben. 
    var result = i.a.Where(s => s.Kilometers == 0).Count();
    Console.WriteLine("Anzahl: {0}", result);
}
static void LinqCount2(InitializerClass i)
{
    //Anzahl von den Autos von Mercedes welche als Sitzbezug Polyester haben. 
    var result = i.m.Where(s => s.SeatCover == "Polyester").Count();
    Console.WriteLine("Anzahl: {0}", result);
}
static void LinqMax1(InitializerClass i)
{
    //Maximumpreis von dem Auto von Volkswagen welches mit Erdgas tankt. 
    var result = i.vw.Where(s => s.Fuel == "Natural Gas").Max(s => s.Price);
    Console.WriteLine("Maximun: {0}", result);
}
static void LinqMax2(InitializerClass i)
{
    //Maximalen Kilometern von dem Auto von Audi welches ein Automatisches Schaltgetriebe hat. 
    var result = i.a.Where(s => s.ManualTransmission == false).Max(s => s.Kilometers);
    Console.WriteLine("Maximun: {0}", result);

}
static void LinqMin1(InitializerClass i)
{
    //Minimalpreis von dem Auto von Mercedes welches nicht unfallfrei ist. 
    var result = i.a.Where(s => s.AccidentFree == true).Min(s => s.Price);
    Console.WriteLine("Minimum: {0}", result);
}
static void LinqMin2(InitializerClass i)
{
    //Minimaleigengewicht von dem Auto von Volkswagen welches eine Vollkaskoversicherung hat. 
    var result = i.vw.Where(s => s.Insurance == EInsurance.FULLYCOMPREHENSIVE).Min(s => s.TareWeight);
    Console.WriteLine("Minimum: {0}", result);

}
static void LinqSum1(InitializerClass i)
{
    //Summe des Preises von den Autos von Mercedes welche als Sitzbezug Art Velour haben.
    var result = i.m.Where(s => s.SeatCover == "Art Velour").Sum(s => s.Price);
    Console.WriteLine("Summe: {0}", result);
}
static void LinqSum2(InitializerClass i)
{
    //Summe des Eigengewichts von den Autos von Mercedes welche ein Leasing haben.
    var result = i.m.Where(s => s.Leasing == true).Sum(s => s.TareWeight);
    Console.WriteLine("Summe: {0}", result);

}
static void LinqFirst1(InitializerClass i)
{
    //Gib das erste Auto von Volkswagen aus, welches AddBlue verwendet. Gib das Modell und den Kilometerstand aus. 
    var result = i.vw.Where(s => s.AddBlue == true).Select(s => new { Modell = s.Modell, s.Kilometers }).First();
    Console.WriteLine("Erstes: {0}", result);
}
static void LinqFirst2(InitializerClass i)
{
    //Gib das erste Auto von Audi aus, welches Kunstleder als Sitzbezug hat. Gib das Modell und den Kilometerstand aus.
    var result = i.a.Where(s => s.SeatCover == "Faux leather").Select(s => new { Modell = s.Modell, s.Kilometers }).First();
    Console.WriteLine("Erstes: {0}", result);
}
static void LinqLast1(InitializerClass i)
{
    //Gib das letzte Auto von Audi aus, welches eine Haftpflichtversicherung hat. Gib das Modell und den Kilometerstand aus.
    var result = i.a.Where(s => s.Insurance == EInsurance.LIABILITY).Select(s => new { Modell = s.Modell, s.Kilometers }).Last();
    Console.WriteLine("Letzes: {0}", result);
}
static void LinqLast2(InitializerClass i)
{
    //Gib das letze Auto von Merces aus, welches als PS mehr als 300 hat. Gib das Modell und den Kilometerstand aus.
    var result = i.m.Where(s => s.PS >= 300).Select(s => new { Modell = s.Modell, s.Kilometers }).Last();
    Console.WriteLine("Letzes: {0}", result);
}
static void LinqSingle1(InitializerClass i)
{
    //Gib die einzige G-Klasse von Mercedes aus und dessen PS. 
    var result = i.m.Where(s => s.Modell == "G-Klasse").Select(s => new { Modell = s.Modell, Kilometer = s.Kilometers }).Single();
    Console.WriteLine("Einziges: {0}", result);
}
static void LinqSingle2(InitializerClass i)
{
    //
    var result = i.m.Where(s => s.Fuel == "Hybrid").Select(s => new { Modell = s.Modell, Sitzbezug = s.SeatCover }).Single();
    Console.WriteLine("Einziges: {0}", result);
}