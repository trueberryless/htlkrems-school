﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ItemToSurvive
{
    internal class TentVM : INotifyPropertyChanged
    {
        string type;
        int size;
        bool flynet;
        string color;
        string material;

        EMaterial ematerial;
        EType etype;
        EFlynet eflynet;

        public string Color { get { return color; } set { color = value; OnPropertyChanged(); } }
        public string Material { get { return material; } set { material = value; OnPropertyChanged(); } }
        public string Type { get { return type; } set { type = value; OnPropertyChanged(); } }
        public int Size { get { return size; } set { size = value; OnPropertyChanged(); } }
        public bool Flynet { get { return flynet; } set { flynet = value; OnPropertyChanged(); } }

        public EMaterial eMaterial { get { return ematerial; } set { ematerial = value; OnPropertyChanged(); } }
        public enum EMaterial { POLYSTER, NYLON, COTTOM};

        public EType eType { get { return etype; } set { etype = value; OnPropertyChanged(); } }
        public enum EType { DOME, TUNEL, TARP }

        public EFlynet eFlynet { get { return eflynet; } set { eflynet = value; OnPropertyChanged(); } }
        public enum EFlynet { YES, NO}

        public override string ToString()
        {
            return base.ToString() + $"Material: {Material} Color: {Color} Type: {Type} Size: {Size} Flynet: {Flynet}";
        }
        public string ToCsv()
        {
            return $"{Material};{Color};{Type};{Size};{Flynet}";
        }

        public static string Path { get; private set; }

        public static List<TentVM> ReadFromFile()
        {
            using (StreamReader sr = new StreamReader(Path))
            {
                List<TentVM> tent = new List<TentVM>();
                while (sr.Peek() != -1)
                {
                    TentVM t = new TentVM();
                    string line = sr.ReadLine();
                    string[] parts = line.Split(';');
                    t.Material = parts[0];
                    t.Color = parts[1];
                    t.Type = parts[2];
                    t.Size = Int32.Parse(parts[3]);
                    t.Flynet = Boolean.Parse(parts[4]);
                    tent.Add(t);
                }
                return tent;
            }
        }
        public static void WriteInFile(ParacordVM paracord)
        {
            using (StreamWriter sw = new StreamWriter(Path))
            {
                sw.WriteLine(paracord.ToCsv());
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
