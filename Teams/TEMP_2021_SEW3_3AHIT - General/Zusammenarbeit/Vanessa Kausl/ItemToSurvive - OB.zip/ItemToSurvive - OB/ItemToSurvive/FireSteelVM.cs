﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ItemToSurvive
{
    internal class FireSteelVM : INotifyPropertyChanged
    {
        int size;
        int weight;
        bool waterproof;
        string color;
        string material;

        EMaterial ematerial;

        public string Color { get { return color; } set { color = value; OnPropertyChanged(); } }
        public string Material { get { return material; } set { material = value; OnPropertyChanged(); } }
        public int Size { get { return size; } set { size = value; OnPropertyChanged(); } }
        public int Weight { get { return weight; } set { weight = value; OnPropertyChanged(); } }
        public bool Waterproof { get { return waterproof; } set { waterproof = value; OnPropertyChanged(); } }

        public EMaterial eMaterial { get { return ematerial; } set { ematerial = value; OnPropertyChanged(); } }
        public enum EMaterial { MAGNESIUM, ALÙMINIUM, STEEL}

        public override string ToString()
        {
            return base.ToString() + $"Material: {Material} Color: {Color} Waterproof: {Waterproof} Weight: {Weight} Size: {Size}";
        }
        public string ToCsv()
        {
            return $"{Material};{Color};{Weight};{Waterproof};{Size}";
        }

        public static string Path { get; private set; }
        
        public static List<FireSteelVM> ReadFromFile()
        {
            using (StreamReader sr = new StreamReader(Path))
            {
                List<FireSteelVM> firesteel = new List<FireSteelVM>();
                while (sr.Peek() != -1)
                {
                    FireSteelVM f = new FireSteelVM();
                    string line = sr.ReadLine();
                    string[] parts = line.Split(';');
                    f.Material = parts[0];
                    f.Color = parts[1];
                    f.Weight = Int32.Parse(parts[2]);
                    f.Waterproof = Boolean.Parse(parts[3]);
                    f.Size = Int32.Parse(parts[4]);
                    firesteel.Add(f);
                }
                return firesteel;
            }
        }
        public static void WriteInFile(FireSteelVM firesteel)
        {
            using (StreamWriter sw = new StreamWriter(Path))
            {
                sw.WriteLine(firesteel.ToCsv());
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
