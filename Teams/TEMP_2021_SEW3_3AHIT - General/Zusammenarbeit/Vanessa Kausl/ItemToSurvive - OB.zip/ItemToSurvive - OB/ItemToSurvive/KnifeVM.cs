﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ItemToSurvive
{
    internal class KnifeVM : INotifyPropertyChanged
    {
        string sharpness;
        int weight;
        string bladetype;
        string color;
        string material;

        EMaterial ematerial;
        ESharpness esharpness;
        EBladetype ebladetype;

        public string Color { get { return color; } set { color = value; OnPropertyChanged(); } }
        public string Material { get { return material; } set { material = value; OnPropertyChanged(); } }
        public string Sharpness { get { return sharpness; } set { sharpness = value; OnPropertyChanged(); } }
        public int Weight { get { return weight; } set { weight = value; OnPropertyChanged(); } }
        public string Bladetype { get { return bladetype; } set { bladetype = value; OnPropertyChanged(); } }

        public EMaterial eMaterial { get { return ematerial; } set { ematerial = value; OnPropertyChanged(); } }
        public enum EMaterial { PLASTIC, WOOD, MICARTA };

        public ESharpness eSharpness { get { return esharpness; } set { esharpness = value; OnPropertyChanged(); } }
        public enum ESharpness { PLUNT, SHAPPY, SHARP, VERYSHARP }

        public EBladetype eBladetype { get { return ebladetype; } set { ebladetype = value; OnPropertyChanged(); } }
        public enum EBladetype { NORMAL, TRAILINGPOINT, SPEARPOINT, NEEDLEPOINT }

        public ICommand SaveCommand { get; private set; }
        public ICommand LoadCommand { get; private set;}
        public ObservableCollection<KnifeVM> List { get; private set; }

        public KnifeVM()
        {
            Path = @"..\..\..\knife.csv";
            SaveCommand = new CmdSaveKnife(this);
            LoadCommand = new CmdLoadKnife(this);
            List = new ObservableCollection<KnifeVM>();
        }

        public override string ToString()
        {
            return $"Material: {Material} Color: {Color} Sharpness: {Sharpness} Weight: {Weight} Bladetype: {Bladetype}";
        }
        public string ToCsv()
        {
            return $"{Material};{Color};{Sharpness};{Weight};{Bladetype}";
        }

        public static string Path { get; private set; }
        
        public static List<KnifeVM> ReadFromFile()
        {
            using (StreamReader sr = new StreamReader(Path))
            {
                List<KnifeVM> knife = new List<KnifeVM>();
                while (sr.Peek() != -1)
                {
                    KnifeVM k = new KnifeVM();
                    string line = sr.ReadLine();
                    string[] parts = line.Split(';');
                    k.Material = parts[0];
                    k.Color = parts[1];
                    k.Sharpness = parts[2];
                    k.Weight = Int32.Parse(parts[3]);
                    k.Bladetype = parts[4];
                    knife.Add(k);
                }
                return knife;
            }
        }
        public static void WriteInFile(KnifeVM knife)
        {
            using (StreamWriter sw = new StreamWriter(Path, true))
            {
                sw.WriteLine(knife.ToCsv());
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
