﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ItemToSurvive
{
    internal class FishingUtilitiesVM : INotifyPropertyChanged
    {
        int length_string;
        int count_hook;
        int size_hook;
        string color;
        string material;

        EMaterial ematerial;

        public string Color { get { return color; } set { color = value; OnPropertyChanged(); } }
        public string Material { get { return material; } set { material = value; OnPropertyChanged(); } }
        public int Length_string { get { return length_string; } set { length_string = value; OnPropertyChanged(); } }
        public int Count_Hook { get { return count_hook; } set { count_hook = value; OnPropertyChanged(); } }
        public int Size_Hook { get { return size_hook; } set { size_hook = value; OnPropertyChanged(); } }

        public EMaterial eMaterial { get { return ematerial; } set { ematerial = value; OnPropertyChanged(); } }
        public enum EMaterial { SPLICING, FIBERGLASS, CARBONFIBER, BAMBOO };

        public override string ToString()
        {
            return base.ToString() + $"Material: {Material} Color: {Color} Size_Hook: {Size_Hook} Count_Hook: {Count_Hook} Length_string: {Length_string}";
        }
        public string ToCsv()
        {
            return $"{Material};{Color};{Size_Hook};{Count_Hook};{Length_string}";
        }

        public ICommand SaveCommand { get; private set; }
        public ICommand LoadCommand { get; private set; }
        public ObservableCollection<FishingUtilitiesVM> List { get; private set; }

        public FishingUtilitiesVM()
        {
            Path = @"..\..\..\fishingutilities.csv";
            SaveCommand = new CmdSaveFU(this);
            LoadCommand = new CmdLoadFU(this);
            List = new ObservableCollection<FishingUtilitiesVM>();
        }

        public static string Path { get; private set; }

        public static List<FishingUtilitiesVM> ReadFromFile()
        {
            using (StreamReader sr = new StreamReader(Path))
            {
                List<FishingUtilitiesVM> fishingutilities = new List<FishingUtilitiesVM>();
                while (sr.Peek() != -1)
                {
                    FishingUtilitiesVM f = new FishingUtilitiesVM();
                    string line = sr.ReadLine();
                    string[] parts = line.Split(';');
                    f.Material = parts[0];
                    f.Color = parts[1];
                    f.Size_Hook = Int32.Parse(parts[2]);
                    f.Count_Hook = Int32.Parse(parts[3]);
                    f.Length_string = Int32.Parse(parts[4]);
                    fishingutilities.Add(f);
                }
                return fishingutilities;
            }
        }
        public static void WriteInFile(FishingUtilitiesVM fishingutilities)
        {
            using (StreamWriter sw = new StreamWriter(Path))
            {
                sw.WriteLine(fishingutilities.ToCsv());
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
