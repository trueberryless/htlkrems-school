﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ItemToSurvive
{
    public class ParacordVM : INotifyPropertyChanged
    {
        int length;
        int thickness;
        string strength;
        string color;
        string material;

        EMaterial ematerial;
        EStrength estrength;

        public string Color { get { return color; } set { color = value; OnPropertyChanged(); } }
        public string Material { get { return material; } set { material = value; OnPropertyChanged(); } }
        public int Length { get { return length; } set { length = value; OnPropertyChanged(); } }
        public int Thickness { get { return thickness; } set { thickness = value; OnPropertyChanged(); } }
        public string Strength { get { return strength; } set { strength = value; OnPropertyChanged(); } }

        public EMaterial eMaterial { get { return ematerial; } set { ematerial = value; OnPropertyChanged(); } }
        public enum EMaterial { POLYESTER, NYLON}

        public EStrength eStrength { get { return estrength; } set { estrength = value; OnPropertyChanged(); } }
        public enum EStrength { I, IA, II, IIA}
        public override string ToString()
        {
            return base.ToString() + $"Material: {Material} Color: {Color} Length: {Length} Thickness: {Thickness} Strength: {Strength}";
        }
        public string ToCsv()
        {
            return $"{Material};{Color};{Length};{Thickness};{Strength}";
        }

        public static string Path { get; private set; }

        public static List<ParacordVM> ReadFromFile()
        {
            using (StreamReader sr = new StreamReader(Path))
            {
                List<ParacordVM> paracord = new List<ParacordVM>();
                while (sr.Peek() != -1)
                {
                    ParacordVM p = new ParacordVM();
                    string line = sr.ReadLine();
                    string[] parts = line.Split(';');
                    p.Material = parts[0];
                    p.Color = parts[1];
                    p.Length = Int32.Parse(parts[2]);
                    p.Thickness = Int32.Parse(parts[3]);
                    p.Strength = parts[4];
                    paracord.Add(p);
                }
                return paracord;
            }
        }
        public static void WriteInFile(ParacordVM paracord)
        {
            using (StreamWriter sw = new StreamWriter(Path))
            {
                sw.WriteLine(paracord.ToCsv());
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
