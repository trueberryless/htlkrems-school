﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NodeProgramm
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            MyLinkedList mll = new MyLinkedList();
            mll.Head = new Node(3);
            mll.Append(5);
            mll.Append(11);
            mll.InsertFront(2);
            mll.PrintList();
        }
    }
    public class MyLinkedList
    {
        public Node Head { get; set; }

        public void Append(Node n)
        {
            if (Head == null)
                Head = n;
            else
            {
                Node temp = Head;
                while (temp.Next != null)
                    temp = temp.Next;
                temp.Next = n;
            }

        }
        public void InsertFront(Node n)
        {
            if (n != null)
            {
                n.Next = Head;
                Head = n;
            }
        }
        public void Append(int data)
        {
            Node n = new Node(data);
            Append(n);
        }
        public void InsertFront(int data)
        {
            Node n = new Node(data);
            InsertFront(n);
        }
        public Node Search(int data)
        {
            return Search(Head, data);
        }
        public Node Search(Node start, int data)
        {
            if (start == null || Head == null)
            {
                Console.WriteLine("Liste ist leer");
                return null;
            }
            while (start!=null)
            {
                if (start.Data == data)
                {
                    Console.WriteLine("Gefunden: " + data);
                    return start;
                }
                else
                    start = start.Next;
            }
            Console.WriteLine("nix gefunden");
            return null;
        }
        public Node Remove(Node r)
        {
            if (Head == null)
            {
                Console.WriteLine("Liste leer");
                return null;
            }
            if(r == null)
            {
                Console.WriteLine("r darf nicht null sein");
                return null;
            }
            if (r == Head)
            {
                Head = Head.Next;
                r.Next = null;
                return r;
            }
            Node temp = Head;
            while (temp != null)
            {
                if (temp.Next == r)
                {
                    temp.Next = r.Next;
                    r.Next = null;
                    return r;
                }
                else
                    temp = temp.Next;
            }
            return null;

        }
        public bool IsSorted()
        {
            if (Head == null)
            {
                Console.WriteLine("Liste leer");
                return false;
            }
            Node temp = Head;
            while (temp.Next != null)
            {
                if (temp.Next.Data < temp.Data)
                    return false;
                else
                    temp = temp.Next;
            }
            return true;
        }
        public Node FindMinimum()
        {
            if (Head == null)
            {
                Console.WriteLine("Liste leer");
                return null;
            }
            Node temp = Head;
            Node min = Head;
            while (temp != null)
            {
                if (temp.Data < min.Data)
                    min = temp;
                temp = temp.Next;
            }
            return min;
        }
        public Node FindMaximum()
        {
            if (Head == null)
            {
                Console.WriteLine("Liste leer");
                return null;
            }
            Node temp = Head;
            Node max = Head;
            while (temp != null)
            {
                if (temp.Data > max.Data)
                    max = temp;
                temp = temp.Next;
            }
            return max;
        }
        public void InsertSorted(Node n)
        {
            if (Head == null)
            {
                Console.WriteLine("Liste leer");
                return;
            }
            if (n.Data<Head.Data)
            {
                n.Next = Head.Next;
                Head = n;
            }
            Node temp = Head;
            while (temp.Next != null)
            {
                if (n.Data < temp.Next.Data)
                {
                    n.Next = temp.Next;
                    temp.Next = n;
                    break;
                }
                temp = temp.Next;
            }
        }

        public void PrintList()
        {
            Node temp = Head;
            while (temp != null)
            {
                Console.WriteLine(temp.Data);
                temp = temp.Next;
            }
        }
    }
    public class Node
    {
        public int Data { get; set; }
        public Node Next { get; set; }
        public Node(int d)
        {
            Data = d;
        }
    }
}
