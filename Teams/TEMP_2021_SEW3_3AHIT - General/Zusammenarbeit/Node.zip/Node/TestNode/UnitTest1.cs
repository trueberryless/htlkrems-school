using NUnit.Framework;
using NodeProgramm;

namespace TestNode
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestSearch_Remove()
        {
            MyLinkedList mll = new MyLinkedList();
            mll.Head = new Node(1);
            mll.Append(2);
            mll.Append(3);
            mll.Append(4);
            mll.Append(5);
            mll.Append(6);
            mll.PrintList();
            Node found = mll.Search(mll.Head, 3);
            Assert.AreEqual(3, found.Data);
            mll.Remove(found);
            found = mll.Search(3);
            Assert.IsNull(found);

            found = mll.Search(mll.Head, 7);
            Assert.IsNull(found);
        }
        [Test]
        public void TestIsSorted_InsertSorted()
        {
            MyLinkedList mll = new MyLinkedList();
            mll.Append(1);
            mll.Append(2);
            mll.Append(3);
            mll.Append(4);
            mll.Append(6);
            mll.Append(7);
            Assert.IsTrue(mll.IsSorted());
            Node n = new Node(7);
            mll.InsertSorted(n);
            mll.InsertFront(7);
            Assert.IsFalse(mll.IsSorted());
        }
        [Test]
        public void TestMax_Min()
        {
            MyLinkedList mll = new MyLinkedList();
            Node min = new Node(1);
            mll.Append(min);
            mll.Append(2);
            mll.Append(3);
            mll.Append(4);
            mll.Append(5);
            Node max = new Node(6);
            mll.Append(max);
            Assert.AreSame(mll.FindMaximum(), max);
            Assert.AreSame(mll.FindMinimum(), min);
        }
    }
}