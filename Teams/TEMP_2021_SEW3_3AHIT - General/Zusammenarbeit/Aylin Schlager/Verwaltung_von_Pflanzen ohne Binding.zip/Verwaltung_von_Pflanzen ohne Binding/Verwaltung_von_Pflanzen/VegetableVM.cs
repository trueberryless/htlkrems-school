﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Verwaltung_von_Pflanzen
{
    public enum ESize { SMALL, MEDIUM, LARGE, XLARGE}
    public class VegetableVM : Plants
    {
        public static string Path { get; private set; }
        public bool islike;
        public ESize sizee;
        public bool isLike
        {
            get
            {
                return islike;
            }
            set
            {
                islike = value;
                OnPropertyChanged();
            }
        }
        public bool isNotLike
        {
            get
            {
                return !islike;
            }
            set
            {
                islike = !value;
                OnPropertyChanged();
            }
        }
        public ESize Size
        {
            get
            {
                return sizee;
            }
            set
            {

                sizee = value;
                OnPropertyChanged();
            }
        }
        public ObservableCollection<VegetableVM> Output4 { get; private set; }
      
        public VegetableVM()
        {
            Path = @"vega.csv";
            
            Output4 = new ObservableCollection<VegetableVM>();
        }
        public override string ToString() //erledigt
        {
            string likeit;
            string size;
            if (Size == ESize.SMALL)
            {
                size = "small";
            }
            else if (Size == ESize.MEDIUM)
            {
                size = "medium";
            }
            else if (Size == ESize.LARGE)
            {
                size = "large";
            }
            else if (Size == ESize.XLARGE)
            {
                size = "X large";
            }
            else
            {
                size = "small";
            }
            
            likeit = isLike ? "like" : "don't like";
            return base.ToString() + $" I {likeit} it. It is {size}.";
        }
        public new string ToCSV()
        {
            return base.ToCSV() + $"{isLike};{Size}";
        } //erledigt
        public static void WriteToFile(VegetableVM vege)
        {
            StreamWriter sw = new StreamWriter(Path, true);
            sw.WriteLine(vege.ToCSV());
            sw.Close();
        } //erledigt
        public static List<VegetableVM> ReadFromFile()
        {
            StreamReader sr = new StreamReader(Path);
            List<VegetableVM> vege = new List<VegetableVM>();
            while (sr.Peek() != -1)
            {
                VegetableVM v = new VegetableVM();
                string line = sr.ReadLine();
                string[] word = line.Split(';');
                v.Name = word[0];
                v.Occur = word[1];                            
                v.isLike = Boolean.Parse(word[2]);
                v.Size = Enum.Parse<ESize>(word[3]);
                vege.Add(v);
            }
            return vege;
        } //erledigt
    }
    
    
}
