﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Verwaltung_von_Pflanzen
{
    public enum EHanging { NOTHING, FRUITS, NUTS }
    public class TreesVM : Plants
    {
        public static string Path { get; private set; }
        public bool isGreen;
         
        public EHanging hangi;
        public bool IsGreen { 
            get
            {
                return isGreen;
            }
            set
            {
                isGreen = value;
                OnPropertyChanged();
            }
        }
        public EHanging Hang
        {
            get
            {
                return hangi;
            }
            set
            {

                hangi = value;
                OnPropertyChanged();
            }
        }
        public ObservableCollection<TreesVM> Output3 { get; private set; }
        public ICommand SaveCommand { get; private set; }
        public ICommand LoadCommand { get; private set; }

        public TreesVM()
        {
            Path = @"trees.csv";
            SaveCommand = new CmdSaveTree(this);
            LoadCommand = new CmdLoadTree(this);
            Output3 = new ObservableCollection<TreesVM>();
        }

        public override string ToString() //erledigt
        {
            string hang;
            if (Hang == EHanging.NOTHING)
            {
                hang = "nothing";

            }
            else if (Hang == EHanging.FRUITS)
            {
                hang = "fruits";
            }
            else if (Hang == EHanging.NUTS)
            {
                hang = "nuts";
            }
            else
            {
                hang = "nothing";
            }
            string col = IsGreen ? "green" : "automnal";
            return base.ToString() + $" is {col} which has {hang} hanging on it.";
        }
        public new string ToCSV() 
        {
            return base.ToCSV() + $"{isGreen};{Hang}";
        } //erledigt
        public static void WriteToFile(TreesVM tree)
        {
            StreamWriter sw = new StreamWriter(Path, true);
            sw.WriteLine(tree.ToCSV());
            sw.Close();
        } //erledigt
        public static List<TreesVM> ReadFromFile() //erledigt
        {
            StreamReader sr = new StreamReader(Path);
            List<TreesVM> tree = new List<TreesVM>();
            while (sr.Peek() != -1)
            {
                TreesVM t = new TreesVM();
                string line = sr.ReadLine();
                string[] word = line.Split(';');
                t.Name = word[0];
                t.Occur = word[1];
                t.IsGreen = Boolean.Parse(word[2]);
                t.Hang = (EHanging) Enum.Parse<EHanging>(word[3]);
                tree.Add(t);
            }
            return tree;
        }
    }
  
}
