﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Verwaltung_von_Pflanzen
{
    public enum EState {HEALTHY, DRYING, BLOOMING  }
    public class ShrubVM : Plants
    {
        public static string Path { get; private set; }
        public bool isberry = true;
        public EState statee;
        public bool isBerry
        {
            get
            {
                return isberry;
            }
            set
            {
                isberry = value;
                OnPropertyChanged();
            }
        }
        public EState State
        {
            get
            {
                return statee;
            }
            set
            {
                statee = value;
                OnPropertyChanged();
            }
        }

        public ShrubVM()
        {
            Path = @"shrubs.csv";
            
            Output2 = new ObservableCollection<ShrubVM>();
        }
        public ObservableCollection<ShrubVM> Output2 { get; set; }
        
        public override string ToString()
        {
            string state;
            if (State == EState.HEALTHY)
            {
                state = "healthy";
            }
            else if (State == EState.DRYING)
            {
                state = "drying";
            }

            else if (State == EState.BLOOMING)
            {
                state = "blooming";
            }
            else
            {
                state = "healthy";
            }
            
            string berries = isBerry ? "berries" : "noberries";
            return base.ToString() + $" is {state}, but also has {berries}.";
        } //erledigt
        public new string ToCSV()
        {
            return base.ToCSV() + $"{isberry};{State}";
        }

        public static void WriteToFile(ShrubVM shrub)
        {
            StreamWriter sw = new StreamWriter(Path, true);
            sw.WriteLine(shrub.ToCSV());
            sw.Close();
        }
        public static List<ShrubVM> ReadFromFile() //erledigt
        {
            StreamReader sr = new StreamReader(Path);
            List<ShrubVM> shrub = new List<ShrubVM>();
            while (sr.Peek() != -1)
            {
                ShrubVM s = new ShrubVM();
                string line = sr.ReadLine();
                string[] word = line.Split(';');
                s.Name = word[0];
                s.Occur = word[1];
                s.isBerry = Boolean.Parse(word[2]);
                s.State = (EState)Enum.Parse<EState>(word[3]);
                shrub.Add(s);
            }
            return shrub;
        }

    }
    
    
}
