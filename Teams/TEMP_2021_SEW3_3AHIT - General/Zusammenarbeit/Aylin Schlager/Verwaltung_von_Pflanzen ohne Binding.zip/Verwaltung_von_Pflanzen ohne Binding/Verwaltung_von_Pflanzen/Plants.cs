﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Verwaltung_von_Pflanzen
{
    
    public class Plants : INotifyPropertyChanged
    {
        public string name;
        public string occur;
        
        public event PropertyChangedEventHandler PropertyChanged;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                OnPropertyChanged();
            }
        }

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public string Occur
        {
            get
            {
                return occur;
            }
            set
            {
                occur = value;
                OnPropertyChanged();
            }
        }
       
        

        public string ToCSV()
        {
            return $"{Name};{Occur};";
        }
        public override string ToString()
        {
            return  $"{Name} comes from {Occur} and ";
        }

    }
}
