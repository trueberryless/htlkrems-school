﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Verwaltung_von_Pflanzen
{
    public enum EColor { ORANGE, RED, BLUE, YELLOW, VIOLETT }
    public class FlowerVM : Plants
    {
        public static string Path { get; private set; }
        public EColor flowercolor;
        public EColor Flowercolor
        {
            get
            {
                return flowercolor;
            }
            set
            {
                flowercolor = value;
                OnPropertyChanged();
            }
        }
        public ObservableCollection<FlowerVM> Output1 { get; private set; }
        
        

        public FlowerVM()
        {
            Path = @"Flower.csv";
            
            Output1 = new ObservableCollection<FlowerVM>();
        }


        public override string ToString() //erledigt
        {
            string flowerc;
            if (Flowercolor == EColor.ORANGE)
            {
                flowerc = "orange";
            }
            else if (Flowercolor == EColor.RED)
            {
                flowerc = "red";
            }
            else if (Flowercolor == EColor.BLUE)
            {
                flowerc = "blue";
            }
            else if (Flowercolor == EColor.YELLOW)
            {
                flowerc = "yellow";
            }
            else if (Flowercolor == EColor.VIOLETT)
            {
                flowerc = "violett";
            }
            else
            {
                flowerc = "red";
            }
            return base.ToString() + $" is {flowerc}.";
        }
        public new string ToCSV()
        {
            return base.ToCSV() + $"{Flowercolor}";
        } //erledigt
        public static void WriteToFile(FlowerVM flower)
        {
            StreamWriter sw = new StreamWriter(Path, true);
            sw.WriteLine(flower.ToCSV());
            sw.Close();
        } //erledigt
        public static List<FlowerVM> ReadFromFile() //erledigt
        {
            StreamReader sr = new StreamReader(Path);
            List<FlowerVM> flower = new List<FlowerVM>();
            while (sr.Peek() != -1)
            {
                FlowerVM f  = new FlowerVM();
                string line = sr.ReadLine();
                string[] word = line.Split(';');
                f.Name = word[0];
                f.Occur = word[1];
                f.Flowercolor = (EColor)Enum.Parse<EColor>(word[2]);
                flower.Add(f);
            }
            return flower;
        }
    }
    
}
