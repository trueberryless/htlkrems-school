﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Verwaltung_von_Pflanzen
{
    public enum ETaste { SWEET, BITTER, HOT, AROMATIC }
    public class HerbVM : Plants
    {
        public static string Path { get; private set; }
        
        public ETaste tastee;
        public ETaste Taste
        {
            get { return tastee; }
            set
            {
                tastee = value;
                OnPropertyChanged();
            }
        }
        public HerbVM()
        {
            Path = @"herbs.csv";
            
            Output5 = new ObservableCollection<HerbVM>();
        }
        public override string ToString()
        {
            string taste;
            if (Taste == ETaste.AROMATIC)
            {
                taste = "aromatic";
            }
            else if (Taste == ETaste.BITTER)
            {
                taste = "bitter";
            }
            else if (Taste == ETaste.HOT)
            {
                taste = "hot";
            }
            else if (Taste == ETaste.SWEET)
            {
                taste = "sweet";
            }
            else
                taste = "bitter";
            return base.ToString() + $"tastes {taste}.";
        } //erledigt
        public new string ToCSV()
        {
            return base.ToCSV() + $"{Taste}";
        }
        public static void WriteToFile(HerbVM herb)
        {
            StreamWriter sw = new StreamWriter(Path, true);
            sw.WriteLine(herb.ToCSV());
            sw.Close();
        }
        public static List<HerbVM> ReadFromFile()
        {
            StreamReader sr = new StreamReader(Path);
            List<HerbVM> herb = new List<HerbVM>();
            while (sr.Peek() != -1)
            {
                HerbVM h = new HerbVM();
                string line = sr.ReadLine();
                string[] word = line.Split(';');
                h.Name = word[0];
                h.Occur = word[1];
                h.Taste = (ETaste)Enum.Parse<ETaste>(word[2]);
                herb.Add(h);
            }
            return herb;
        } //erledigt
        public ObservableCollection<HerbVM> Output5 { get; private set; }
       


    }
    
    
}
