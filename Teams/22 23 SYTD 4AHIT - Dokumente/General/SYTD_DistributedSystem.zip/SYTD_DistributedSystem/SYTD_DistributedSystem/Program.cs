using System.Text.Json;
using SYTD_DistributedSystem.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/students", async () =>
{
    var schuelerList1 = await JsonSerializer.DeserializeAsync<List<Schueler>>(File.OpenRead("Resources/schueler.json"));
    //return schuelerList1;

    var httpClient = new HttpClient();
    var schuelerList2 = await httpClient.GetFromJsonAsync<List<Schueler>>("http://127.0.0.1:5000/students");

    return schuelerList1.Concat(schuelerList2);
});

app.Run();