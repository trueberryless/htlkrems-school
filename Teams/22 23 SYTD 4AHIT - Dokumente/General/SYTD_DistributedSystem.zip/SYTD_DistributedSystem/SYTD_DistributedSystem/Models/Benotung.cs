﻿namespace SYTD_DistributedSystem.Models
{
    public class Benotung
    {
        public int Note { get; set; }
        public Benotungstyp Typ { get; set; }
    }
}