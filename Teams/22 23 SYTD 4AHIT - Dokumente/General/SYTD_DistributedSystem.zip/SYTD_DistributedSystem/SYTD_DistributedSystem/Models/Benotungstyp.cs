﻿namespace SYTD_DistributedSystem.Models
{
    public enum Benotungstyp
    {
        Mitarbeit,
        Test,
        Referat
    }
}
