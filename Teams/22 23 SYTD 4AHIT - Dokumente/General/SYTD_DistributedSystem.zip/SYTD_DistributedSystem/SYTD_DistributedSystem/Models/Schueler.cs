﻿namespace SYTD_DistributedSystem.Models
{
    public class Schueler
    {
        public int KatalogNummer { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
    }
}