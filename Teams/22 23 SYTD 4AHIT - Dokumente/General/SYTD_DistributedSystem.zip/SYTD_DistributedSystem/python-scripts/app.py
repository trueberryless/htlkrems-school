from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/test")
def test():
    return jsonify("<h1>It works!</h1>")

@app.route("/favicon.ico")
def icon():
    return ""

@app.route("/students")
def students():
    return jsonify([
        {
            'KatalogNummer': 4,
            'Vorname': 'Valentin',
            'Nachname': 'Fritz'
        },
        {
            "KatalogNummer": 5,
            "Vorname": "Dominik",
            "Nachname": "Fuchs"
        },
        {
            "KatalogNummer": 6,
            "Vorname": "Felix",
            "Nachname": "Gotthart"
        }
    ])