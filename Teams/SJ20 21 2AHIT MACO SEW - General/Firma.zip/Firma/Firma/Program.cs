﻿using System;

namespace Firma
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Person a = new Person();
            Person b = new Person("Susi");
            Person c = new Person("Tom", "Turbo");

        }
    }
}
