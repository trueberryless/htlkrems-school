﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Firma
{
    class Employee:Person
    {

        int salary;

        public void Pointless_Method() {
            // innerhalb einer Methode kann ich auf alle Variablen der
            // eigenen Klasse zugreifen
            // egal ob public, protected oder private

            // aber nur auf jene Variablen der Basisklasse,           
            // die public oder protected sind


            Console.WriteLine(firstname);
            //Console.WriteLine(surname); //private in Basisklasse
        }
    }
}
