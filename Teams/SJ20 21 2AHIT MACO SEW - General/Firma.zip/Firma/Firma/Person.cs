﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Firma
{
    class Person
    {
        protected string firstname;
        private string surname;

        // Konstruktorenverkettung: ein Konstruktor ruft den anderen auf
        // Das mit vererbung und base machen wir nächste Woche
        public Person():this("(nicht bekannt)", "(unbekannt)") {

            // dieser Copy&Paste code fällt weg, wenn man
            // die Konstruktorenverkettung geschickt verwendet

            //this.firstname = "(nicht bekannt)";
            //this.surname = "(unbekannt)";
        }
        public Person(string firstname):this(firstname,"(unbekannt)")
        {
            // dieser Copy&Paste code fällt weg, wenn man
            // die Konstruktorenverkettung geschickt verwendet

            //this.firstname = firstname;
        }

        // Dieser Konstruktor erledigt die "Hauptarbeit"
        // die beiden anderen Konstruktoren will ich als
        // Hilfskonstruktoren bezeichnen 
        // damit eben Personen ohne bekannten Vor- oder Nachnamen
        // im Main (Zeile 11 und 12) angelegt werden können
        public Person(string firstname, string surname)
        {
            this.firstname = firstname;
            this.surname = surname;
        }

        public void Example_Method()
        {
            // innerhalb einer Methode kann ich auf alle Variablen der
            // eigenen Klasse zugreifen
            // egal ob public, protected oder private
            Console.WriteLine(firstname);
            Console.WriteLine(surname);

        }

    }
}
