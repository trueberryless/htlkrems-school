﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;

            // int x = Randomer.Next(1, 10);
            
            Master m = new Master(500);
            m.Run();

            //Urtier ut = new Urtier(20, 20);
            //Urtier ut1 = new Urtier(20, 20);
            //Urtier ut2 = new Urtier(20, 20);
            //ut.Show();

            //while (true)
            //{

            //    ut.Move();
            //    ut1.Move();
            //    ut2.Move();
            //    System.Threading.Thread.Sleep(25);
            //}

            Console.ReadKey();
        }
    }
}
