﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Point
    {

        char symbol;
        
        private int x;
        public int X
        {
            get { return x; }
            set
            {
                if ((value >= 0) && (value < Console.WindowWidth))
                    x = value;
            }
        }

        private int y;

        public int Y
        {
            get { return y; }
            set { if ((value  >= 0)&&(value < Console.WindowHeight)) 
                        y = value; }
        }

        public Point()
        {
            X = 0;
            Y = 0;
            symbol = '█';
        }
        
        public Point(int x, int y)
        {
            X = x;
            Y = y;
            symbol = '█';
        }

        public Point(int x, int y, char s)
        {
            X = x;
            Y = y;
            symbol = s;
        }

        public bool IsOnXY(int x_out, int y_out)
        {
            if ((x == x_out) && (y == y_out))
                return true;
            else
                return false;
        }

        public void Show()
        {
            Console.SetCursorPosition(x, y);
            Console.Write(symbol);
        }

    }
}
