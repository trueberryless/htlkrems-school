﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    static class Randomer
    {
        static Random randerer = new Random();

        static public int Next(int a, int b)
        {
            return randerer.Next(a, b);
        }



    }
}
