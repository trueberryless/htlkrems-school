﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Master
    {
        List<SingleMover> sl = new List<SingleMover>();
        bool running;
        int round = 0;
        int old_x;
        int old_y;
        int wait;
        int[] colorCount; 

        public Master(int amount)
        {
            colorCount = new int[8]; 
            wait = 10;
            running = true;
            for (int i = 0; i < amount; i++)
            {
                sl.Add(new SingleMover(Randomer.Next(0,Console.WindowWidth-1), Randomer.Next(0,Console.WindowHeight)));
            }
        }
        public void Run()
        {
           
            while (running)
            {
                for (int i = 0; i < sl.Count; i++)
                {
                    round++;
                    old_x = sl[i].pos.X;
                    old_y = sl[i].pos.Y; 
                    sl[i].Move();
                    if (round > 10000)
                    {
                        UrtierCrashed(i);
                        System.Threading.Thread.Sleep(wait);
                    }
                    RedrawBelow(old_x, old_y) ;
                   
                    
                }
            }
        }

        private void UrtierCrashed(int i)
        {
            
            for(int j=0;j<sl.Count;j++)
            {
                if (i != j)
                    if ((sl[i].pos.X == sl[j].pos.X) &&
                        (sl[i].pos.Y == sl[j].pos.Y))
                        sl[j].fg = sl[i].fg;
            }
            
        }

        private void RedrawBelow(int x_old, int y_old)
        {
            for (int j = 0; j < sl.Count; j++)
            {

                if ((x_old == sl[j].pos.X) &&
                    (y_old == sl[j].pos.Y))
                {
                    sl[j].Show();
                }
                //else 
                //{
                //    Console.SetCursorPosition(50, 0);
                //    Console.Write(j);
                //}
            }
        }

        private ConsoleColor CountColors()
        {

            for (int i = 0; i < colorCount.Length; i++)
            {
                switch (sl[i].fg)
                { 
                }
            }
            return ConsoleColor.Red;
        }



        
    }
}
