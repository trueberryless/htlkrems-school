﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Urtier
    {
        static Random randy = new Random();
        public Point pos;
        protected direction dir;
        public ConsoleColor fg;
        public ConsoleColor bg;

        public Urtier(int x, int y)
        {
            fg = RandomColor();
            //bg = ConsoleColor.Black;
            dir = direction.N;
            pos = new Point(x, y);
        }

        public void Show()
        {
            Console.ForegroundColor = fg;
            //Console.BackgroundColor = bg;
           
            pos.Show();
        }

        public virtual void Move()
        {
            MoveDirection();
        }
        protected void MoveDirection()
        {
            int x_old = pos.X;
            int y_old = pos.Y;
            dir = GetDirectionRandom();
            switch (dir)
            {
                case direction.N:
                    pos.Y--;
                    break;
                case direction.S:
                    pos.Y++;
                    break;
                case direction.W:
                    pos.X-=2;
                    break;
                case direction.E:
                    pos.X+=2;
                    break;
            }
            Show();
            Console.SetCursorPosition(x_old, y_old);
            Console.Write(' ');
                    
        }

        private direction GetDirectionRandom()
        {
            switch (Randomer.Next(1,5))
            {
                case 1:
                    return direction.N;
                case 2:
                    return direction.S;
                case 3:
                    return direction.E;
                case 4:
                    return direction.W;
                default:
                    return direction.N;
            }
        }

        private ConsoleColor RandomColor()
        {
            switch (Randomer.Next(1, 9))
            {               
                case 1: return ConsoleColor.White;
                case 2: return ConsoleColor.Blue;
                case 3: return ConsoleColor.Green;
                case 4: return ConsoleColor.Red;
                case 5: return ConsoleColor.Cyan;
                case 6: return ConsoleColor.Magenta;
                case 7: return ConsoleColor.Yellow;
                case 8: return ConsoleColor.Gray;
                default:
                    return ConsoleColor.DarkMagenta;
            }
        }

    }
}
