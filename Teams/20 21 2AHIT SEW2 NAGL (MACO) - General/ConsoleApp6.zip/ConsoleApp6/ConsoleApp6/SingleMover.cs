﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    enum direction {N,S,E,W};
    

    class SingleMover:Urtier
    {
        


        public SingleMover(int x, int y) : base(x, y)
        {
        }

        // public override void Move()
        //{
        //    dir = GetDirectionRandom();
        //    MoveDirection();
        // }

        

    }
}
