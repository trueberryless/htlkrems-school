/* JavaScript VintageCalculator  V1.0
   HTL Krems 2020/21
   2AHIT 
   MEDT
*/  
//alert("I am here!");
debugger;
var elem;
//       text = '';
//   elem.addEventListener("keydown", KeyDownPressed );


function c_init()
{
    // document.getElementById("c_displayText").innerHTML = "Hallo";
    elem = document.getElementById("c_body");
    elem.addEventListener("keydown", KeyDownPressed );
}

function KeyDownPressed(evt)
{
    debugger;
    let zeichen = String.fromCharCode(evt.charCode);
    let c_key = `${evt.key}`;
    document.getElementById("c_displayText").innerHTML = `<strong>Taste gedrückt</strong>: <br> key: `+c_key  ;
}