﻿namespace Model.Entities;

public enum EOccupationType
{
    ACTOR,
    DIRECTOR,
    PRODUCER
}