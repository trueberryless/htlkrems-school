﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model.Entities;

[Table("E_STATES")]
public class State
{
    [Key]
    [Column("STATE_CODE"), StringLength(100)]
    public string StateCode { get; set; }
}