namespace Model.Entities.Facilities; 

public class Faculty : AFacility {

}