namespace Model.Entities; 

public enum EAttackType {
    MELEE_ATTACK
}