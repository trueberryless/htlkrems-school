namespace Model.Entities; 

public enum ESpeed {
    
}