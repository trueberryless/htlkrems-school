﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public abstract class ASchiff : INotifyPropertyChanged
    {
        #region Variables
        private string? name;
        private int laenge;
        private DateTime baujahr;

        public event PropertyChangedEventHandler? PropertyChanged;

        public string? Name
        {
            get { return name; }
            set {
                if (name != value)
                {
                    name = value;
                    this.OnPropertyChanged("Name");
                }
            }
        }

        public int Laenge
        {
            get { return laenge; }
            set {
                if (laenge != value)
                {
                    laenge = value;
                    this.OnPropertyChanged("Laenge");
                }
            }
        }

        public DateTime Baujahr
        {
            get { return baujahr; }
            set {
                if (baujahr != value) {
                    baujahr = value;
                    this.OnPropertyChanged("Baujahr");
                }
            }
        }
        #endregion

        #region Constructors
        public ASchiff(string? name, int laenge, DateTime baujahr)
        {
            this.Name = name;
            this.Laenge = laenge;
            this.Baujahr= baujahr;
        }

        public ASchiff(string name, int laenge) : this(name, laenge, new DateTime(0)) { }

        public ASchiff(string name) : this(name, 0, new DateTime(0)) { }

        public ASchiff(string name, DateTime baujahr) : this(name, 0, baujahr) { }

        public ASchiff() : this(null, 0, new DateTime(0)) { }
        #endregion

        #region Methods
        public override string ToString()
        {
            return String.Format($"Das Schiff {Name} ist {Laenge}m lang und wurde {Baujahr} erbaut.");
        }

        public virtual string ToCSV()
        {
            return String.Format($"{Name};{Laenge};{Baujahr}");
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if(PropertyChanged != null)
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
