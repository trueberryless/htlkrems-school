﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public class Fischereischiff : ASchiff
    {
        #region Variables
        private int netzgroesse;
        private int fischlagerkapazitaet;

        public int Netzgroesse
        {
            get { return netzgroesse; }
            set { 
                if (netzgroesse != value)
                {
                    netzgroesse = value;
                    this.OnPropertyChanged("Netzgroesse");
                }
            }
        }

        public int Fischlagerkapazitaet
        {
            get { return fischlagerkapazitaet; }
            set { 
                if (fischlagerkapazitaet != value)
                {
                    fischlagerkapazitaet = value;
                    this.OnPropertyChanged("Fischlagerkapazitaet");
                }
            }
        }
        #endregion

        #region Constructors
        public Fischereischiff(string name, int laenge, DateTime baujahr, int netzgroesse, int fischlagerkapazitaet) : base(name, laenge, baujahr)
        {
            this.Netzgroesse = netzgroesse;
            this.Fischlagerkapazitaet = fischlagerkapazitaet;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Außerdem hat es ein Netz mit einer FLäche von {Netzgroesse}m² und es kann bis zu {Fischlagerkapazitaet} Fische lagern.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{Netzgroesse};{Fischlagerkapazitaet}");
        }
        public void ToFile(List<Fischereischiff> schiffe)
        {
            using (StreamWriter sw = new StreamWriter("fischereischiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Fischereischiff> FromFile()
        {
            List<Fischereischiff> fischereischiffe = new List<Fischereischiff>();
            using (StreamReader sr = new StreamReader("fischereischiffe.csv"))
            {
                while (sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if (inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        fischereischiffe.Add(new Fischereischiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            Int32.Parse(schiff[3]),
                            Int32.Parse(schiff[4])
                            )
                        );
                    }
                }

            }
            return fischereischiffe;
        }
        #endregion
    }
}
