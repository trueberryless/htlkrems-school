﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public class Dampfschiff : ASchiff
    {
        #region Variables
        private int co2ausstoss;
        private int passagiere;

        public int CO2Ausstoss
        {
            get { return co2ausstoss; }
            set {
                if (CO2Ausstoss != value)
                {
                    co2ausstoss = value;
                    this.OnPropertyChanged("CO2Ausstoss");
                }
            }
        }

        public int Passagiere
        {
            get { return passagiere; }
            set {
                if (Passagiere != value)
                {
                    passagiere = value;
                    this.OnPropertyChanged("Passagiere");
                }
            }
        }
        #endregion

        #region Constructors
        public Dampfschiff(string name, int laenge, DateTime baujahr, int co2ausstoss, int passagiere) : base(name, laenge, baujahr)
        {
            this.CO2Ausstoss = co2ausstoss;
            this.Passagiere = passagiere;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Dieses Schiff stößt {CO2Ausstoss}CO2 pro Meile aus und trägt {Passagiere} Passagiere.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{CO2Ausstoss};{Passagiere}");
        }
        public void ToFile(List<Dampfschiff> schiffe)
        {
            using (StreamWriter sw = new StreamWriter("dampfschiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Dampfschiff> FromFile()
        {
            List<Dampfschiff> dampfschiffe = new List<Dampfschiff>();
            using (StreamReader sr = new StreamReader("dampfschiffe.csv"))
            {
                while (sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if (inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        dampfschiffe.Add(new Dampfschiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            Int32.Parse(schiff[3]),
                            Int32.Parse(schiff[4])
                            )
                        );
                    }
                }

            }
            return dampfschiffe;
        }
        #endregion
    }
}
