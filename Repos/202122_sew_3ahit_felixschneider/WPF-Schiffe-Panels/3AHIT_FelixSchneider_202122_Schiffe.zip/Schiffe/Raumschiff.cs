﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public class Raumschiff : ASchiff
    {
        #region Variables
        private int maxgeschwindigkeit;
        private int anzahllaserkanonen;
        private int anzahlfluegel;

        public int MaxGeschwindigkeit
        {
            get { return maxgeschwindigkeit; }
            set { 
                if(maxgeschwindigkeit != value)
                {
                    maxgeschwindigkeit = value;
                    this.OnPropertyChanged("MaxGeschwindigkeit");
                }
            }
        }

        public int AnzahlLaserkanonen
        {
            get { return anzahllaserkanonen; }
            set { 
                if(anzahllaserkanonen != value)
                {
                    anzahllaserkanonen = value;
                    this.OnPropertyChanged("AnzahlLaserkanonen");
                }
            }
        }

        public int AnzahlFluegel
        {
            get { return anzahlfluegel; }
            set {
                if (anzahlfluegel != value)
                {
                    anzahlfluegel = value;
                    this.OnPropertyChanged("AnzahlFluegel");
                }
            }
        }
        #endregion

        #region Constructors
        public Raumschiff(string name, int laenge, DateTime baujahr, int maxgeschwindigkeit, int anzahllaserkanonen, int anzahlfluegel) : base(name, laenge, baujahr)
        {
            this.MaxGeschwindigkeit = maxgeschwindigkeit;
            this.AnzahlLaserkanonen = anzahllaserkanonen;
            this.AnzahlFluegel = anzahlfluegel;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Dieses Raumschiff kann maximal mit {MaxGeschwindigkeit}m/s fliegen, hat {AnzahlFluegel} Flügel und {AnzahlLaserkanonen} Laserkanonen.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{MaxGeschwindigkeit};{AnzahlLaserkanonen};{AnzahlFluegel}");
        }

        public void ToFile(List<Raumschiff> schiffe)
        {
            using(StreamWriter sw = new StreamWriter("raumschiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Raumschiff> FromFile()
        {
            List<Raumschiff> raumschiffe = new List<Raumschiff>();
            using(StreamReader sr = new StreamReader("raumschiffe.csv"))
            {
                while(sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if(inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        raumschiffe.Add(new Raumschiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            Int32.Parse(schiff[3]),
                            Int32.Parse(schiff[4]),
                            Int32.Parse(schiff[5])
                            )
                        );
                    }
                }

            }
            return raumschiffe;
        }
        #endregion
    }
}
