﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public enum Flagge { undefined, Deutschland, Norwegen, England, Spanien, Russland, USA, China, Japan }
    public class Ruderschiff : ASchiff
    {
        #region Variables
        private int ruderanzahl;
        private Flagge flagge;

        public int Ruderanzahl
        {
            get { return ruderanzahl; }
            set { 
                if (ruderanzahl != value)
                {
                    ruderanzahl = value;
                    this.OnPropertyChanged("Ruderanzahl");
                }
            }
        }

        public Flagge Flagge
        {
            get { return flagge; }
            set {
                if (flagge != value)
                {
                    flagge = value;
                    this.OnPropertyChanged("Flagge");
                }
            }
        }
        #endregion

        #region Constructors
        public Ruderschiff(string name, int laenge, DateTime baujahr, int ruderanzahl, Flagge flagge) : base(name, laenge, baujahr)
        {
            this.Ruderanzahl = ruderanzahl;
            this.Flagge = flagge;
        }

        public Ruderschiff(string name, int laenge, DateTime baujahr, int ruderanzahl) : this(name, laenge, baujahr, ruderanzahl, new Flagge()) { }

        public Ruderschiff(string name, int laenge, DateTime baujahr, Flagge flagge) : this(name, laenge, baujahr, 0, flagge) { }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Außerdem hat es {Ruderanzahl} Ruder und es hat die {Flagge}-Flagge.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{Ruderanzahl};{Flagge}");
        }
        public void ToFile(List<Ruderschiff> schiffe)
        {
            using (StreamWriter sw = new StreamWriter("ruderschiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Ruderschiff> FromFile()
        {
            List<Ruderschiff> ruderschiffe = new List<Ruderschiff>();
            using (StreamReader sr = new StreamReader("ruderschiffe.csv"))
            {
                while (sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if (inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        ruderschiffe.Add(new Ruderschiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            Int32.Parse(schiff[3]),
                            (Flagge)Enum.Parse(typeof(Flagge), schiff[4])
                            )
                        );
                    }
                }

            }
            return ruderschiffe;
        }
        #endregion
    }
}
