﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public enum Hafen { undefined, Rotterdam, NewYork, LosAngeles, Hongkong, Tianjin, Busan, Qingdao, Shenzhen, Singapur, Shanghai }

    public class Frachtschiff : ASchiff
    {
        #region Variables
        private Hafen routeVon;
        private Hafen routeNach;

        public Hafen RouteVon
        {
            get { return routeVon; }
            set { 
                if (routeVon != value)
                {
                    routeVon = value;
                    this.OnPropertyChanged("RouteVor");
                }
            }
        }

        public Hafen RouteNach
        {
            get { return routeNach; }
            set { 
                if (routeNach != value)
                {
                    routeNach = value;
                    this.OnPropertyChanged("RouteNach");
                }

            }
        }
        #endregion

        #region Constructors
        public Frachtschiff(string name, int laenge, DateTime baujahr, Hafen routeVon, Hafen routeNach) : base(name, laenge, baujahr)
        {
            this.RouteVon = routeVon;
            this.RouteNach = routeNach;
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Es fährt von {RouteVon} nach {RouteNach}.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{RouteVon};{RouteNach}");
        }
        public void ToFile(List<Frachtschiff> schiffe)
        {
            using (StreamWriter sw = new StreamWriter("frachtschiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Frachtschiff> FromFile()
        {
            List<Frachtschiff> frachtschiffe = new List<Frachtschiff>();
            using (StreamReader sr = new StreamReader("frachtschiffe.csv"))
            {
                while (sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if (inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        frachtschiffe.Add(new Frachtschiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            (Hafen)Enum.Parse(typeof(Hafen), schiff[3]),
                            (Hafen)Enum.Parse(typeof(Hafen), schiff[4])
                            )
                        );
                    }
                }

            }
            return frachtschiffe;
        }
        #endregion
    }
}
