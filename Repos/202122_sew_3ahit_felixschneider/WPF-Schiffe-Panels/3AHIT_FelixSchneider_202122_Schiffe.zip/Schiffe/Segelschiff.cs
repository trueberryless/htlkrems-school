﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public enum Segelmaterial { undefined, Gewebe, Laminat, Polyester, SolidStripes, Carbon, Aramid, Pentex, Vectran, Nylon }

    public class Segelschiff : ASchiff
    {
        #region Variables
        private int segelhoehe;
        private Segelmaterial segelmaterial;

        public int Segelhoehe
        {
            get { return segelhoehe; }
            set { 
                if (segelhoehe != value)
                {
                    segelhoehe = value;
                    this.OnPropertyChanged("Segelhoehe");
                }
            }
        }

        public Segelmaterial Segelmaterial
        {
            get { return segelmaterial; }
            set { 
                if (segelmaterial != value)
                {
                    segelmaterial = value;
                    this.OnPropertyChanged("Segelmaterial");
                }
            }
        }
        #endregion

        #region Constructors
        public Segelschiff(string name, int laenge, DateTime baujahr, int segelhoehe, Segelmaterial segelmaterial) : base(name, laenge, baujahr)
        {
            this.Segelhoehe = segelhoehe;
            this.Segelmaterial = segelmaterial;
        }

        public Segelschiff(string name, int laenge, DateTime baujahr, int segelhoehe) : this(name, laenge, baujahr, segelhoehe, new Segelmaterial()) { }

        public Segelschiff(string name, int laenge, DateTime baujahr, Segelmaterial segelmaterial) : this(name, laenge, baujahr, 0, segelmaterial) { }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Außerdem hat es {Segelhoehe}m Segelhöhe und das Segel besteht aus {Segelmaterial}.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{Segelhoehe};{Segelmaterial}");
        }
        public void ToFile(List<Segelschiff> schiffe)
        {
            using (StreamWriter sw = new StreamWriter("segelschiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Segelschiff> FromFile()
        {
            List<Segelschiff> segelschiffe = new List<Segelschiff>();
            using (StreamReader sr = new StreamReader("segelschiffe.csv"))
            {
                while (sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if (inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        segelschiffe.Add(new Segelschiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            Int32.Parse(schiff[3]),
                            (Segelmaterial)Enum.Parse(typeof(Segelmaterial), schiff[4])
                            )
                        );
                    }
                }

            }
            return segelschiffe;
        }
        #endregion
    }
}
