﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schiffe
{
    public enum Farbe { undefined, Blau, Gruen, Gelb, Rot, Rosa, Violet, Orange, Braun }
    public enum Marke { undefined, Hotweels, LEGO, Playmobil, Hasbro, Mattel, Simba, Fuehrer }

    public class Spielzeugschiff : ASchiff
    {
        #region Variables
        private Farbe farbe;
        private Marke marke;

        public Farbe Farbe
        {
            get { return farbe; }
            set {
                if (farbe != value)
                {
                    farbe = value;
                    this.OnPropertyChanged("Farbe");
                }
            }
        }

        public Marke Marke
        {
            get { return marke; }
            set {
                if (marke != value)
                {
                    marke = value;
                    this.OnPropertyChanged("Marke");
                }
            }
        }
        #endregion

        #region Constructors
        public Spielzeugschiff(string name, int laenge, DateTime baujahr, Farbe farbe, Marke marke) : base(name, laenge, baujahr)
        {
            this.Farbe = farbe;
            this.Marke = marke;
        }

        public Spielzeugschiff(string name, int laenge, DateTime baujahr, Farbe farbe) : this(name, laenge, baujahr, farbe, new Marke()) { }

        public Spielzeugschiff(string name, int laenge, DateTime baujahr, Marke marke) : this(name, laenge, baujahr, new Farbe(), marke) { }
        #endregion

        #region Methods
        public override string ToString()
        {
            return base.ToString() + String.Format($"Außerdem ist das Spielzeug {Farbe} und produziert von {Marke}.");
        }

        public override string ToCSV()
        {
            return base.ToCSV() + String.Format($";{Farbe};{Marke}");
        }

        public void ToFile(List<Spielzeugschiff> schiffe)
        {
            using (StreamWriter sw = new StreamWriter("spielzeugschiffe.csv"))
            {
                foreach (var schiff in schiffe)
                {
                    sw.WriteLine(schiff.ToCSV());
                }
            }
        }

        public List<Spielzeugschiff> FromFile()
        {
            List<Spielzeugschiff> spielzeugschiffe = new List<Spielzeugschiff>();
            using (StreamReader sr = new StreamReader("spielzeugschiffe.csv"))
            {
                while (sr.Peek() != -1)
                {
                    string? inhalt = sr.ReadLine();
                    if (inhalt != null)
                    {
                        string[] schiff = inhalt.Split(';');
                        spielzeugschiffe.Add(new Spielzeugschiff(
                            schiff[0],
                            Int32.Parse(schiff[1]),
                            DateTime.Parse(schiff[2]),
                            (Farbe)Enum.Parse(typeof(Farbe), schiff[3]),
                            (Marke)Enum.Parse(typeof(Marke), schiff[4])
                            )
                        );
                    }
                }

            }
            return spielzeugschiffe;
        }
        #endregion
    }
}
