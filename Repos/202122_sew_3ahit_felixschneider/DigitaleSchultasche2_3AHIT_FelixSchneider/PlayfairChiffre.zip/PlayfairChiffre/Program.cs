﻿PlayfairChiffre.PlayfairChiffre pc = new PlayfairChiffre.PlayfairChiffre("Schlüssel");

string test = pc.Encryption("Zonendatei");
Console.WriteLine(test);

test = pc.Decryption(test);
Console.WriteLine(test);

Console.ReadLine(); 
