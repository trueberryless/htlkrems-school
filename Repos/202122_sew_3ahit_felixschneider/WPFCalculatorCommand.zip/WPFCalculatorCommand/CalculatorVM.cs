﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WPFCalculatorCommand
{
   
    public class CalculatorVM : INotifyPropertyChanged
    {
        public ICommand CmdAdd { get; private set; }
        public ICommand CmdSubt { get; private set; }
        public ICommand CmdMult { get; private set; }
        public ICommand CmdDiv { get; private set; }
       
        public CalculatorVM()
        {
            CmdAdd = new AddCommand(this);
            CmdSubt = new SubtCommand(this);
            CmdMult = new RelayCommand((o) => Result = Value1 * Value2);
            CmdDiv = new RelayCommand((o) => Result = Value1 / Value2);

        }

        public void Mult(){Result = Value1 * Value2; }

        public decimal Value1 { get; set; }
        public decimal Value2 { get; set; }
        private decimal result;
        public decimal Result {
            get { return result; }
            set {
                    result = value;
                    OnPropertyChanged(); 
                }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
    public class AddCommand : ICommand
    {
        private CalculatorVM myCalc;
        public event EventHandler CanExecuteChanged;

        public AddCommand(CalculatorVM c) {
            this.myCalc =c;
        }
        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            myCalc.Result = myCalc.Value1 + myCalc.Value2;
        }
       
    }
    public class SubtCommand : ICommand
    {
        private CalculatorVM myCalc;
        public event EventHandler CanExecuteChanged;

        public SubtCommand(CalculatorVM c)
        {
            this.myCalc = c;
        }
        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            myCalc.Result = myCalc.Value1 - myCalc.Value2;
        }
    }
    public class RelayCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private Action<object> execute;

        public RelayCommand(Action<object> exec)
        {
            this.execute = exec;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            execute(parameter);
        }
    }
}
